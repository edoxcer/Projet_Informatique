import java.io.*;
import java.net.*;
import java.util.*;


class ObjetStocke implements Serializable {
    private static final long serialVersionUID = 1L;
    /*
    Un serialVersionUID est un numéro de version, associé à
toute classe implémentant l’interface Serializable.
■ il permet de s’assurer que lors de la désérialisation les versions
des classes Java sont concordantes.
■ Si le test échoue, une InvalidClassException est levée.
■ Une classe sérialisable peut déclarer explicitement son
serialVersionUID
■ Si une classe sérialisable ne déclare pas explicitement un
serialVersionUID, Java en calcule un par défaut.
■ Il est fortement recommandé de déclarer explicitement le
serialVersionUID.*/
    private String id;
    private String nom;
    private String description;

    public ObjetStocke(String id, String nom, String description) {
        this.id = id;
        this.nom = nom;
        this.description = description;
    }

    public String getId() { return id; }
    public String getNom() { return nom; }
    public String getDescription() { return description; }

    @Override
    public String toString() {
        return "ObjetStocke{id='" + id + "', nom='" + nom + "', description='" + description + "'}";
    }
}

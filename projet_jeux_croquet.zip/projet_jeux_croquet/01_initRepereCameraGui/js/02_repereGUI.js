const borneVue=6;//amplitude de deplacement de la camera

 
function init(){
 var stats = initStats();
// creation de rendu et de la taille
 let rendu = new THREE.WebGLRenderer({ antialias: true });
 rendu.shadowMap.enabled = true;
 let scene = new THREE.Scene();   
 let camera = new THREE.PerspectiveCamera(20, window.innerWidth / window.innerHeight, 0.1, -100);
 rendu.shadowMap.enabled = true;
 rendu.setClearColor(new THREE.Color(0xFFFFFF));
 rendu.setSize(window.innerWidth*.9, window.innerHeight*.9);
 cameraLumiere(scene,camera);
 lumiere(scene);
 repere(scene);
 let sphere; // Variable pour stocker la balle



  let diff = selecdiff();
  let nbalea =0;
  if (diff == 3){
     nbalea=Math.floor(Math.random()*2); // pour la diff  == 3 expert on fait choisir entre 2 courbes 0 et 1
     console.log(nbalea); 
  }
  else {
     nbalea = Math.floor(Math.random() * 3); // si diff es == 2 on a donc un choix alea entre 0 et 3 qui est le nb de courbe
     console.log(nbalea); 
  }

 let Courbe_retourner1 =CreattiondesCourbes(diff,scene,nbalea); // 2 première courbe

 console.log(Courbe_retourner1);








 
 //********************************************************
 //
 //  D E B U T     M E N U     G U I
 //
 //********************************************************
 var gui = new dat.GUI();//interface graphique utilisateur
  // ajout du menu dans le GUI
 let menuGUI = new function () {
   this.cameraxPos = camera.position.x;
   this.camerayPos = camera.position.y;
   this.camerazPos = camera.position.z;
   this.cameraZoom = 10;
   this.cameraxDir = 0;
   this.camerayDir = 0;
   this.camerazDir = 0;
   this.couleurArceaux = 0x00FF00;


  this.miseAjourArceaux = function () {
      const couleurArceaux = {
        rouges: 0xFF0000,
        bleu: 0x0000FF,
        vert: 0x00FF00,
        magenta: 0xFF00FF,
      };
      const couleur = couleurArceaux[this.couleurArceaux];
      ensembleArceaux(couleur,diff,nbalea); // recrée les arceaux avec la nouvelle couleur
    };
   //pour actualiser dans la scene   
   this.actualisation = function () {
    posCamera();
    reAffichage();
   }; // fin this.actualisation
 }; // fin de la fonction menuGUI
 // ajout de la camera dans le menu
 ajoutCameraGui(gui,menuGUI,camera)
 //ajout du menu pour actualiser l'affichage 
 gui.add(menuGUI, "actualisation");
 let phongMenu = gui.addFolder("Couleur des Arceaux");
 phongMenu.open();
 phongMenu
   .add(menuGUI, "couleurArceaux", ["rouges", "bleu", "vert", "magenta"]) // Liste des couleurs
   .onChange(() => menuGUI.miseAjourArceaux());// Appelle actualisation à chaque changement
 menuGUI.actualisation()
 //********************************************************
 //
 //  F I N     M E N U     G U I
 //
 //********************************************************
 renduAnim();
ensembleArceaux(0x00FF00,diff,nbalea); // arceaux de base 
sphere =ballespswan(scene);
let tmaillet = 0;
let indicedelaCourbe = 0; // Indice de la courbe courante dans Courbe_retourner1
let t = 0;                // Progression sur la courbe actuelle
let maillet1=maillet(scene, { x: -2, y: 1, z: 1 },{ x: -2, y: 1, z: 3 }); // position de base du maillet j'aurais pu ne pas le mettre en param 
let activation = false; // activation du maillet
sol(scene);
Robot(scene);
animate(); 


function selecdiff(){
  let  rep = prompt("entre la difficulter (3: expert , 2:debutant");
  if (rep == "3" || rep =="2"){
      return rep;
  }
  else {
    return selecdiff();
  }
 }
 

 function ensembleArceaux(couleurArceaux,diff,nbalea){
   if(diff == 3 && nbalea == 1) {
    creationArceaux(scene,{ x: 0, y: 0, z: 0 }, 1.5, 2,couleurArceaux);  
    creationArceaux(scene,{ x: 4, y: -2, z: 0 }, 1.5, 2,couleurArceaux);  
    creationArceaux(scene,{ x: 8, y: 2, z: 0}, 1.5, 2,couleurArceaux);
    creationArceaux(scene,{ x: 12, y: -3, z: 0 }, 1.5, 2,couleurArceaux);
    creationArceaux(scene,{ x: 18, y: 14, z: 0 }, 1.5, 2,couleurArceaux)
    demi_cone(scene,{ x: 28, y: 10, z: 0 })
  }else {
    creationArceaux(scene,{ x: 0, y: 0, z: 0 }, 1.5, 2,couleurArceaux);  
    creationArceaux(scene,{ x: 4, y:0, z: 0 }, 1.5, 2,couleurArceaux);  
    creationArceaux(scene,{ x: 8, y: 2, z: 0}, 1.5, 2,couleurArceaux);
    creationArceaux(scene,{ x: 12, y: 5.5, z: 0 }, 1.5, 2,couleurArceaux);
    creationArceaux(scene,{ x: 18, y: 2.5, z: 0 }, 1.5, 2,couleurArceaux);
    demi_cone(scene,{ x: 28, y: 0, z: 0 })
  }
 }




 function CreattiondesCourbes(diffculter,scene,nbalea){
    // fonction pour le jeux du Croquet :
    // a terme mettre tous les tbalaeaux dans une fonction 'point de controle'
    // difficulter ==2 DEBUTANT
    // difficulter ==3 EXPERT
    tableauxNiveaux =[];
    if (diffculter == 2 /* revien au niveau debutant*/ && nbalea==0){ // perd
      let tabQuadratic = ([
        new THREE.Vector3(0, 1,0), // P0
        new THREE.Vector3(1, 2,0),// P1
        new THREE.Vector3(3, 1,0),// P2
      ]);
      pos = { x: 8, y: 6, z: 0 };
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tabQuadratic,pos,2,2)); // en soit les param '2,3' sont les dégrée des courbes mais ne sont pas obligatoire dans le focntionement car on les def directement en param de notre fonction deg2=2 ,deg3=3 mais je garde au cas ou bug 
      return tableauxNiveaux; // je peut recup les 2 courbes qui sont donc crée avec un return?
      // faire l'animation sur un return de la fonction genererDeuxCourbesJOintes
    }
    if (diffculter==2 && nbalea ==1){// perd
      let tab1 = [
        new THREE.Vector3(0, 1,0),   // P0 
        new THREE.Vector3(1, 1,0),   // P1 
        new THREE.Vector3(2, -1,0),   // P2 
      ];
      posfinal1 = { x: 6, y: -5, z: 0 };
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab1,posfinal1,2,2)); // pas besoin de faire push... car ici on est que avec 2 courbes car le joueur perd
      return tableauxNiveaux;
    }
    if (diffculter ==2 && nbalea ==2){ // perd aussi
      let tab3 = [
        new THREE.Vector3(0, 1,0),   // P0 
        new THREE.Vector3(2, 2,0),   // P1 
        new THREE.Vector3(4, 1,0),   // P2 
      ];
      posfinal2 = { x:8, y: 3, z: 0 };
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab3,posfinal2,2,2));
      return tableauxNiveaux; // perd car il rate un arceaux

    }
    if (diffculter==3 && nbalea ==0){ // gagne 
      let tab3 = [
        new THREE.Vector3(0, 1,0),   // P0 
        new THREE.Vector3(2, 2,0),   // P1 
        new THREE.Vector3(3, 1,0),   // P2 
      ];
      posfinal2 = { x: 8, y: 3, z: 0};
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab3,posfinal2,2,3));/*ici ajouter un idice qui permet de dire deg 3 ou deg2 comme ça dans generer dans courbe jointe on chnage ça simple en vrai*/;
      let tab4 = [
        new THREE.Vector3(posfinal2.x,posfinal2.y,posfinal2.z),   // P0 
        new THREE.Vector3(8, 3,0),   // P1 
        new THREE.Vector3(9, 2,0),   // P2 
        new THREE.Vector3(10, 4,0),   // P3
      ];
      posfinal3= { x: 14, y: 9, z: 0 };
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab4,posfinal3,3,3));
      let tab5 = [
        new THREE.Vector3(posfinal3.x,posfinal3.y,posfinal3.z),   // P0 
        new THREE.Vector3(14, 5,0),   // P1 
        new THREE.Vector3(15, 6 ,0),   // P2 
        new THREE.Vector3(15, 6,0),   // P3
      ];
      posfinal4= { x: 16, y: 2, z: 0 };
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab5,posfinal4,3,3));
      let tab6 = [
        new THREE.Vector3(posfinal4.x,posfinal4.y,posfinal4.z),   // P0 
        new THREE.Vector3(18, 5,0),   // P1 
        new THREE.Vector3(23, 3,0),   // P2 
      ];
      posfinal5= { x: 28, y: 0, z: 0 };
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab6,posfinal5,2,2));

      return tableauxNiveaux;
    }
    if (diffculter ==3 && nbalea==1){ // gagne
      let tab3 = [
        new THREE.Vector3(0, 1,0),   // P0 
        new THREE.Vector3(2, -1,0),   // P1 
        new THREE.Vector3(3, -1,0),   // P2 
      ];
      posfinal2 = { x: 8, y: 3, z: 0};
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab3,posfinal2,2,3));
      let tab4 = [
        new THREE.Vector3(posfinal2.x, posfinal2.y,posfinal2.z),   // P0 
        new THREE.Vector3(10, 3,0),   // P1 
        new THREE.Vector3(11, -1,0),   // P2 
        new THREE.Vector3(10, -2,0),   // P3
      ];
      posfinal3 = { x: 14, y: -1, z: 0};
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab4,posfinal3,3,3));
      let tab5 = [
        new THREE.Vector3(posfinal3.x, posfinal3.y,posfinal3.z),   // P0 
        new THREE.Vector3(16, 3,0),   // P1 
        new THREE.Vector3(21, 4,0),   // P2 
        new THREE.Vector3(14, 12,0),   // P3
      ];
      posfinal4 = { x: 18, y: 15, z: 0};
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab5,posfinal4,3,3));
      let tab6 = [
        new THREE.Vector3(posfinal4.x, posfinal4.y,posfinal4.z),   // P0 
        new THREE.Vector3(18, 15,0),   // P1 
        new THREE.Vector3(22, 15,0),   // P2 
        new THREE.Vector3(24, 10,0),   // P3
      ];
      posfinal5= { x: 28, y: 10, z: 0};
      tableauxNiveaux.push(...genererDeuxCourbesJointes(scene,tab6,posfinal5,3,2));
      return tableauxNiveaux;
    }
 }


 function genererDeuxCourbesJointes(scene, tab, position_Final, degreCourbe1, degreCourbe2) {

  // Définir les points de la première courbe
  let P0 = tab[0];
  let P1 = tab[1];
  let P2 = tab[2];
  console.log("je suis p2 :"+P2);
  let P3=null;
  if(tab.length ===4){ // gestion du deg2 ou 3
    P3 = tab[3];
  }else {
    P3 =null;
  }
  //console.log("je suis P3: "+P3);
  // Création de la première courbe
  let courbe1;
  if (degreCourbe1 === 2) {
      courbe1 = bez2(scene, [P0, P1, P2]); // Courbe de Bézier de degré 2
  } else if (degreCourbe1 === 3) {
      courbe1 = bez3(scene, [P0, P1, P2, P3]); // Courbe de Bézier de degré 3
  }

  // Création des points pour la deuxième courbe
  const P0_prime = tab[tab.length - 1].clone();
  const direction = new THREE.Vector3().subVectors(P0_prime, tab[tab.length - 2]).normalize();
  const P1_prime = P0_prime.clone().add(direction.multiplyScalar(2)); // Aligné avec la tangente
  const P2_prime = new THREE.Vector3(position_Final.x, position_Final.y, position_Final.z); 

  let courbe2;
  if (degreCourbe2 === 2) {
      courbe2 = bez2(scene, [P0_prime, P1_prime, P2_prime]);
  } else if (degreCourbe2 === 3) {
      const P3_prime = new THREE.Vector3(position_Final.x, position_Final.y, position_Final.z);
      courbe2 = bez3(scene, [P0_prime, P1_prime, P2_prime, P3_prime]);
  }

  // Retourner les courbes générées
  return [courbe1, courbe2];
}


function animate() {
  requestAnimationFrame(animate);
  // Récupérer la courbe actuelle
  const courbeCourante = Courbe_retourner1[indicedelaCourbe];
  // Progression sur la courbe actuelle
  const position = courbeCourante.getPointAt(t);
  // parti animation maillet 
  if (t === 0 && !activation) {
    activation = true; // Démarrer l'animation
    maillet1.position.set(position.x, position.y,position.z);
  }
  animation_Maillet(5,maillet1);
  if (position) {
      sphere.position.set(position.x, position.y, position.z || 0);
  }

  // Incrémenter t
  t += 0.009;

  // Vérifier si on a terminé cette courbe
  if (t > 1) {
      t = 0; // Réinitialiser t
      indicedelaCourbe++; // Passer à la courbe suivante

      // Si toutes les courbes ont été parcourues, revenir à la première
      if (indicedelaCourbe >= Courbe_retourner1.length) {
          indicedelaCourbe = 0;
      }
  } 
  // Rendu
  rendu.render(scene, camera);
}

/**
 * 
 * @param {revien a notre scene} scene
 * @param {position que l'on vas donner a notre arceaux (lathe,thore,tube)} position 
 * @param {hauteur on gère la hauteur du deuxième lathe pour faire la jointure lathe1 et lathe2 et thore} hauteur 
 * @param {decalage permet de décaler les latheinv donc l'inverse des lathe(on fait aussi si le thore )} decalage 
 * @param {couleurArceaux permet de mettre une couleur en param qui vas servir pour chaque objt car il ont tous ce paramètre} couleurArceaux 
 */
 function creationArceaux(scene,position, hauteur, decalage,couleurArceaux){
  
  let tablathe1 = [
    new THREE.Vector2(0.2, 0),  // Point de base
    new THREE.Vector2(0.15, 0.1),
    new THREE.Vector2(0.2, 0.2),  // Début de l'élargissement
    new THREE.Vector2(0.2, 0.4), // Section large du vase
    new THREE.Vector2(0.2, 0.6),  // Rétrécissement vers le haut
    new THREE.Vector2(0.15, 0.8),
    new THREE.Vector2(0.1, 1)   // Ouverture en haut
  ];
  let tablathe2 = [
    new THREE.Vector2(0.1, 1), // Correspond à la fin de tablathe1
    new THREE.Vector2(0.15, 1.1),
    new THREE.Vector2(0.2, 1.2),
    new THREE.Vector2(0.2, 1.4),
    new THREE.Vector2(0.15, 1.6),
    new THREE.Vector2(0.09, hauteur)
  ];

  let tabLatheSol = [
    new THREE.Vector2(0.3, 0), 
    new THREE.Vector2(0.15, 0.01),
    new THREE.Vector2(0.16, 0.02),
    new THREE.Vector2(0.2, 0.01),
    new THREE.Vector2(0.4, 0.02),
    new THREE.Vector2(0.1, 0.01)
  ];
  
// lathe qui sont inversée 

  let tabinv = [...tablathe1.map(point => new THREE.Vector2(-point.x, point.y))];
  let tabinv2 = [...tablathe2.map(point => new THREE.Vector2(-point.x , point.y))];
  let tabinv3latheSol= [...tabLatheSol.map(point => new THREE.Vector2(-point.x , point.y))]; // lathe inverse qui fait la jointure avec le sol

  //
  const lathe1 = lathe(tablathe1, scene, 0 , { x: position.x , y: position.y, z: position.z },couleurArceaux);   // Positionné légèrement à droite
  const lathe2 = lathe(tablathe2, scene, 0 , { x: position.x , y: position.y, z: position.z },couleurArceaux);
  const lathe3 = lathe(tabinv3latheSol,scene,0 , { x: position.x , y: position.y, z: position.z },couleurArceaux); // lathe du sol

  //lathe inverse
  const latheInv1 = lathe(tabinv, scene, decalage,{ x: position.x , y: position.y, z: position.z },couleurArceaux); // Positionné légèrement à gauche
  const latheInv2 = lathe(tabinv2, scene, decalage,{ x: position.x , y: position.y, z: position.z },couleurArceaux);
  const latheinvsol = lathe(tabinv3latheSol ,scene,decalage,{ x: position.x , y: position.y, z: position.z },couleurArceaux);

  // permet de faire les jointure G1 entre les lathes et le tube 
  thore(scene, { x:   position.x , y: position.y+0.3, z: position.z+1.5}, Math.PI / 2, 3*Math.PI/2,couleurArceaux);      // Bas gauche
  thore(scene, { x:  position.x , y: position.y + hauteur+0.2/*decalge dans ce cas */ , z: position.z +1.5}, Math.PI / 2, Math.PI/2,couleurArceaux); // Haut gauche


    

  tube(scene,{ x:position.x , y:position.y+1, z: -position.z },decalage-0.51 /*revien a la alongeur de  tube on aurait pu mettre 1.49 aussi car le decalage est de 2*/,couleurArceaux);
  


 }
   // creation de la balle
function ballespswan(scene){
    const balle = 0.5;
    const geometry = new THREE.SphereGeometry(balle, 32, 32);
    const material = new THREE.MeshPhongMaterial({
      color: '#FFA500',
      transparent: false,
      opacity: 1
    });
    const sphere = new THREE.Mesh(geometry, material);
    sphere.position.set(-0.5,1, 0.5);
    scene.add(sphere);
    return sphere;



}
function bez3(scene,tab){
  const curve = new THREE.CubicBezierCurve3( // 3eme degrès donc on a 4 points de contoles 
  ...tab
  );
  
  const points = curve.getPoints(50);
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = new THREE.LineBasicMaterial({ color: '#00008B' });
  const curveObject = new THREE.Line(geometry, material);
  
  scene.add(curveObject); // Ajouter la courbe à la scène
  return curve; // Retourner la courbe pour l'utiliser dans l'animation
}
function bez2(scene ,tab){
  const courbe = new THREE.QuadraticBezierCurve3( // 2eme degrée QuadraticBezierCurve3
    ...tab
  );
  
  const points = courbe.getPoints( 50 );
  const geometry = new THREE.BufferGeometry().setFromPoints( points );
  
  const material = new THREE.LineBasicMaterial( { color: "#00008B" } );
  const courbebez2 = new THREE.Line( geometry, material );

  scene.add(courbebez2);
  return courbe;// Retourner la courbe pour l'utiliser dans l'animation
}
/**
 * 
 * @param {*} tab 
 * @param {*} scene 
 * @param {permet le décalage des arceaux inverse} decalageY 
 * @param {*} position 
 * @param {*} couleur 
 * @returns 
 */
function lathe(tab,scene,decalageY,position,couleur){ // ajouter l'attributs couleur dans le lathe et dans le thor et dnas le tube pour l'arceau complet 
  // le mieux a faire c'est uune lathe avec le sol un cylindre et un lathe puis le thorus qui vas lier avec le cylindre horizontale

  const geometrylathe = new THREE.LatheGeometry( tab );
  const materialathe = new THREE.MeshPhongMaterial( { color: couleur } );
  const lathe = new THREE.Mesh( geometrylathe, materialathe );
  lathe.rotation.x = Math.PI/2;
  lathe.position.set(position.x, position.y+decalageY, position.z);
  scene.add( lathe );
  return lathe
}
function thore(scene, position, rotationx,rotaY,couleur) {
  const material = new THREE.MeshPhongMaterial({ color: couleur});
  const geometry = new THREE.TorusGeometry(0.3, 0.15, 19, 100, Math.PI/2);
  const torus = new THREE.Mesh(geometry, material);

  torus.rotation.x = rotationx;
  torus.rotation.y = rotaY;
  torus.position.set(position.x, position.y, position.z);
  scene.add(torus);
}
function tube(scene,position,longueur,couleur){
    const material = new THREE.MeshPhongMaterial({ color: couleur });
    const geometry = new THREE.CylinderGeometry(0.15, 0.15, longueur, 50); // Ajuster longueur selon besoin
    const tube = new THREE.Mesh(geometry, material);
  
    tube.position.set(position.x,position.y,-position.z+1.8); // par rapport au millieu des tubes 
    //tube.rotation.z = Math.PI / 2; // Rotation pour aligner horizontalement
  
    scene.add(tube);
  }
function demi_cone(scene,position){
  const geometry = new THREE.ConeGeometry(         
    2, // radius
    5, // height
    16, //radial segments,
    4, // height segments
    true, // open ended or capped, false means capped
    Math.PI/2,
    Math.PI, // start angle
    ); 
  const material = new THREE.MeshPhongMaterial( {color: 'orange',side:THREE.DoubleSide} );
  const cone = new THREE.Mesh(geometry, material );
  cone.position.set(position.x, position.y, position.z);
  cone.rotation.y = Math.PI;
  cone.rotation.z = Math.PI/2;
  scene.add(cone);
  return cone;
}  

 function sol(scene){
  const geometry = new THREE.PlaneGeometry( 100, 100 );
  const material = new THREE.MeshBasicMaterial( {color: '#FFB6C1', side: THREE.DoubleSide} );
  const plane = new THREE.Mesh( geometry, material );
  plane.position.set(0,-2,-0.5);
  scene.add( plane );
 // voir doc plane geotmetry
}
function animation_Maillet(dlp_angle, mailletGroup) {
  if (!activation) {return};

  // Progression de l'animation du maillet
  tmaillet += dlp_angle * 0.005;

  if (tmaillet > 1) {
      tmaillet = 0;
      activation = false; // Fin de l'animation
      return;
  }
  // Calcul de l'angle du maillet (oscillation)
  let deplacement_angle = Math.sin(tmaillet * Math.PI) * Math.PI / 4; // -45° à +45°

  // Applique la rotation au groupe du maillet
  mailletGroup.rotation.y= deplacement_angle; // Le groupe entier est animé ici
}


// problème avec l'animation du maillet donc obligation de faire un group THREE GROUPS
function maillet(scene,positionTube,positionManche){

  
  const material = new THREE.MeshPhongMaterial({ color: 0x008B8B });
  const geometry = new THREE.CylinderGeometry(0.40, 0.40, 3,10);
  const tube1 = new THREE.Mesh(geometry, material); // bout
  
  const geometry2= new THREE.CylinderGeometry(0.30, 0.30, 5,10); 
  const manche= new THREE.Mesh(geometry2, material); // manche du maillet
  manche.rotation.x = Math.PI/2;
  manche.position.set(positionManche.x,positionManche.y,positionManche.z) // chnager cette partie jsute décaler par rapport au manche la hauteur du bas 
  tube1.position.set(positionTube.x,positionTube.y,positionTube.z);  // chnager le tube pas le manche 
  tube1.rotation.z=Math.PI/2;

  let grp = new THREE.Group(); 
  grp.add(manche);
  grp.add(tube1);
  scene.add(grp);
  return grp;

}


function Robot(scene){

  let grp_robo = new THREE.Group();

    // bras 1 et 2
    const geometry_bras = new THREE.BoxGeometry( 0.5, 4, 0.2 ); 
    const material_bras = new THREE.MeshPhongMaterial( {color: 0x00ff00} ); 
    let bras1 = new THREE.Mesh( geometry_bras, material_bras ); 
    let bras2 = new THREE.Mesh(geometry_bras,material_bras);
    // jambe 1 et 2
    const geometry_jambes = new THREE.BoxGeometry( 0.5, 4, 0.2 ); 
    const material_jambes = new THREE.MeshPhongMaterial( {color: 0x00ff00} ); 
    let jambe1 = new THREE.Mesh( geometry_jambes, material_jambes ); 
    let jambe2 = new THREE.Mesh(geometry_jambes,material_jambes);

    // tete
    const geometry_tete = new THREE.SphereGeometry(3, 32, 32);
    const material_tete = new THREE.MeshPhongMaterial({
        color: 'red',
        transparent:false,
        opacity: 0.5
      });
    let tete = new THREE.Mesh(geometry_tete, material_tete);

    const geometry_oeil = new THREE.SphereGeometry(0.2, 16, 16);
    const material_oeil = new THREE.MeshPhongMaterial({ color: 0xffffff });
    let oeil1 = new THREE.Mesh(geometry_oeil, material_oeil);
    let oeil2 = new THREE.Mesh(geometry_oeil, material_oeil);

    const geometry_base = new THREE.CylinderGeometry(3, 4.5, 0.5, 32);
    const material_base = new THREE.MeshPhongMaterial({ color: 0x444444 });
    let socle = new THREE.Mesh(geometry_base, material_base);



    // positon des bras et jambes
    bras1.rotation.x = Math.PI/4;
    bras2.rotation.x = -Math.PI/4;
    jambe1.rotation.x = -Math.PI/4;
    jambe2.rotation.x = Math.PI/4;
    socle.rotation.x = Math.PI/2;



    tete.position.set(-11,-2,4);
    bras1.position.set(-11,1,6);
    bras2.position.set(-11,-5,6);
    jambe1.position.set(-11,1,0);
    jambe2.position.set(-11,-5,0);
    oeil1.position.set(-8.5, -3, 5); 
    oeil2.position.set(-8.5, -1, 5); 
    socle.position.set(-11, -2, -0.4); 



    grp_robo.add(tete);
    grp_robo.add(bras1);
    grp_robo.add(bras2);
    grp_robo.add(jambe1);
    grp_robo.add(jambe2);
    grp_robo.add(oeil1);
    grp_robo.add(oeil2);
    grp_robo.add(socle);


  scene.add(grp_robo);
  


  return grp_robo;
}

// code prof 
  // definition des fonctions idoines
 function posCamera(){
  camera.position.set(menuGUI.cameraxPos*testZero(menuGUI.cameraZoom),menuGUI.camerayPos*testZero(menuGUI.cameraZoom),menuGUI.camerazPos*testZero(menuGUI.cameraZoom));
  camera.lookAt(menuGUI.cameraxDir,menuGUI.camerayDir,menuGUI.camerazDir);
  actuaPosCameraHTML();
 }
 
 //affichage dans la page HTML
 function actuaPosCameraHTML(){
  document.forms["controle"].PosX.value=testZero(menuGUI.cameraxPos);
  document.forms["controle"].PosY.value=testZero(menuGUI.camerayPos);
  document.forms["controle"].PosZ.value=testZero(menuGUI.camerazPos); 
  document.forms["controle"].DirX.value=testZero(menuGUI.cameraxDir);
  document.forms["controle"].DirY.value=testZero(menuGUI.camerayDir);
  document.forms["controle"].DirZ.value=testZero(menuGUI.camerazDir);
 } // fin fonction posCamera
  // ajoute le rendu dans l'element HTML
 document.getElementById("webgl").appendChild(rendu.domElement);
   
  // affichage de la scene
 rendu.render(scene, camera);
  
 
 function reAffichage() {
  setTimeout(function () {
   posCamera();
  }, 200);// fin setTimeout(function ()
    // rendu avec requestAnimationFrame
  rendu.render(scene, camera);
 }// fin fonction reAffichage()
 
 
  function renduAnim() {
    stats.update();
    // rendu avec requestAnimationFrame
    requestAnimationFrame(renduAnim);
// ajoute le rendu dans l'element HTML
    rendu.render(scene, camera);



  }

  





  
 
} // fin fonction init()
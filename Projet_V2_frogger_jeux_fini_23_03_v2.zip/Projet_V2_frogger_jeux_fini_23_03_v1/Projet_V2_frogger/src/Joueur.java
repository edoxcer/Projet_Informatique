
public class Joueur extends Thread {
    private String pseudo;
    private int score;
    private int ID;
    //faire en sorte que la grenouille du joueur soit un thread ?
    // gestion des collisions entre les grenouilles ect
    // creation d'un menu
    // gestion des scores


    public Joueur( String pseudo, int  Score,int ID) {
        this.pseudo = pseudo;
        this.score = Score;
        this.ID = ID;
    }

    public Joueur(int Id)
    {
        this.ID = Id;
        this.pseudo = "Joueur"+String.valueOf(Id);
        this.score = 0;
    }

    public int getID() {
        return ID;
    }

    public String getPseudo() {
        return pseudo;
    }
    public int getScore() {
        return score;
    }


    public void augmenterScore() {
        score += 1;
    }
    public int setId(int id)
    {
        return this.ID = id;
    }
    
}

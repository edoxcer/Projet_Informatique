import javax.swing.*;
import java.awt.*;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Serpent {
    private int x;
    private int y;
    private Image image;
    private plateau terrain;
    private int vitesse;
    private int tileSize =32;
    private block block;
    private int direction;

    // constructeur
    public Serpent(int posX, int posY, plateau p, int direction, int vistesse)
    {
        x = posX;
        y = posY;
        this.terrain = p;
        this.vitesse = vistesse;
        this.image = new ImageIcon(getClass().getResource("./Frogger_Img/serpent.png")).getImage();
        this.direction = direction;
        this.block = new block(this.image,posX,posY,tileSize,tileSize);
    }
    public void ActivationTondeuse(Grenouille grenouille)
    {
        Timer timer = new Timer(25, new ActionListener() { // 100 ms pour rafraîchir le tronc
            @Override
            public void actionPerformed(ActionEvent e) {
                Bouger(grenouille);  // Déplace le tronc
                updateImgTondeuse(); // Met à jour son affichage
                terrain.repaint(); // Redessine le plateau pour voir le changement
            }
        });
        timer.start(); // Démarre le Timer
    }
    public void Bouger(Grenouille grenouille)
    {
        //dpl vers la droite
        if(direction==1){
            this.x= this.x+this.vitesse;
        }
        //dpl vers la gauche
        else{
            this.x = this.x - this.vitesse;
        }
        isOut(); // permet de renitialiser la pose de la tondeuse
        interactionGrenouille(grenouille);
    }
    // Vérifie si le tronc sort de l'écran et le replace
    public boolean isOut() {
        if (this.x < 0) {  // Sortie par la gauche
            this.x = 18 * tileSize;  // Replace à droite
            return true;
        } else if (this.x > 18 * tileSize) {  // Sortie par la droite
            this.x = 0;  // Replace à gauche
            return true;
        }
        return false;
    }

    public void updateImgTondeuse()
    {
        this.block.setX_Y(this.x, this.y);
        //System.out.println("TONDEUSE POSITION x: " + this.x + " y: " + this.y);
        block.setImage(this.getImage());
    }
    // faire en sorte que quand la tondeuse  == pose de la grenouille la grenouille meurt
    // donc retour au spawn
    public void interactionGrenouille(Grenouille grenouille)
    {
        int frogX = grenouille.getBlock().getX();
        int frogY = grenouille.getBlock().getY();

        int serpentX = this.x;
        int serpentY = this.y;

        int hitboxSize = 50; // taille de hitbox

        Rectangle hitboxSerpent = new Rectangle(serpentX, serpentY, hitboxSize, hitboxSize);
        Rectangle hitboxGrenouille = new Rectangle(frogX, frogY, tileSize, tileSize);

        if (hitboxSerpent.intersects(hitboxGrenouille)) {
            // La grenouille est touchée par la zone élargie
            grenouille.setX(7);
            grenouille.setY(16);
            grenouille.getBlock().setX_Y(7 * tileSize, 16 * tileSize);
            System.out.println(" Grenouille touchée par le serpent");
        }

        grenouille.updateImgGrenouille();
    }




    public Image getImage() {
        return image;
    }

    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    public plateau getTerrrain() {
        return terrain;
    }
    public int getVitesse() {
        return vitesse;
    }
    public int getDirection() {
        return direction;
    }
    public block getBlock() {
        return block;
    }
    public int getTileSize() {
        return tileSize;
    }
    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }

}
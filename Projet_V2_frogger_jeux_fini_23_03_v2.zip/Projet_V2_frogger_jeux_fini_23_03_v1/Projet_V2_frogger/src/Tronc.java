import java.awt.*;
import javax.swing.*;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tronc {
    private int x;  // En pixels !
    private int y;  // En pixels !
    private int taille;
    private Image image;
    private final int tileSize = 32;
    private block block;
    private plateau terrain;
    private int direction;
    private int vitesse;

    public Tronc(int posX, int posY, plateau p, int d, int v,Image i) {
        this.direction = d;
        this.x = posX ;  // x en pixels
        this.y = posY ;  // y en pixels
        this.terrain = p;
        this.vitesse = v * tileSize;  // vitesse en pixels
        this.image = i;
        this.block = new block(this.image, this.x, this.y, tileSize, tileSize);
    }

    // Active le déplacement automatique du tronc
    public void ActivationTronc() {
        Timer timer = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                flotter();
                updateImgTronc();
                terrain.repaint();
            }
        });
        timer.start();
    }

    // Déplacement du tronc
    public void flotter() {
        if (direction == 1) {
            this.x += this.vitesse; // Déplacement à droite (pixels)
        } else {
            this.x -= this.vitesse; // Déplacement à gauche (pixels)
        }

        // Vérifier si le tronc sort de l'écran
        isOut();
       // deplacerGrenouilleSiDessus();
        // Vérifie si la grenouille est dessus et la déplace
    }

    // Vérifie si le tronc sort de l'écran et le replace
    public boolean isOut() {
        if (this.x < 0) {  // Sortie par la gauche
            this.x = 18 * tileSize;  // Replace à droite
            return true;
        } else if (this.x > 18 * tileSize) {  // Sortie par la droite
            this.x = 0;  // Replace à gauche
            return true;
        }
        return false;
    }


    // Met à jour l'affichage du tronc
    public void updateImgTronc() {
        this.block.setX_Y(this.x, this.y); // Reste en pixels
        block.setImage(this.image);
    }

    public void afficherPosition() {
        System.out.print("La position DU TRONC est :");
        System.out.println("x: " + this.x/tileSize + " y: " + this.y/tileSize); // on affiche leurs position en cases
    }

    public void deplacerGrenouilleSiDessus(Grenouille grenouille) {
        int frogX = grenouille.getX();
        int frogY = grenouille.getY();

        // Vérifie sur toute la longueur du tronc (gauche + droite)
        for (int i = 0; i < 2; i++) {
            int blocX = (this.x / tileSize) + i;
            int blocY = this.y / tileSize;

            if (frogX == blocX && frogY == blocY) {
                // La grenouille est bien sur le tronc
                if (direction == 1) {
                    grenouille.setX(grenouille.getX() + 1);
                } else {
                    grenouille.setX(grenouille.getX() - 1);
                }
                grenouille.updateImgGrenouille();
                return; // On sort dès qu’on l’a déplacée
            }
        }
    }


    // Getter pour récupérer la position en pixels
    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public block getBlock() {
        return this.block;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    public int getDirection() {
        return this.direction;
    }
    public void setDirection(int direction) {
        this.direction = direction;
    }
    public int getVitesse() {
        return this.vitesse;
    }
    public void setVitesse(int vitesse) {
        this.vitesse = vitesse;
    }
    public Image getImage()
    {
        return  this.image;
    }
}
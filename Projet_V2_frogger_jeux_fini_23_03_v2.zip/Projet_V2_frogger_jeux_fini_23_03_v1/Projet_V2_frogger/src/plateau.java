import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class plateau extends JPanel implements KeyListener {
    // Dimensions du plateau
    private int colonnes;
    private int lignes;
    private boolean toucheEnfoncee = false;

    // Carte du jeu sous forme de tableau de chaînes
    private String[] tileMap = {
            "XXXXXXXXXXXXXXXXXXX",
            "XXXSXXXSXXXSXXXSXXX",
            "XPPPPPPPPPPPPPPPPPX",
            "XPPPPPPPPPPPPPPPPPX",
            "XPPPPPPPPPPPPPPPPPX",
            "XEEEEEEEEEEEEEEEEEX",
            "XEEEEEEEEEEEEEEEEEX",
            "XPPPPPPPPPPPPPPPPPX",
            "XPPPPPPPPPPPPPPPPPX",
            "XPPPPPPPPPPPPPPPPPX",
            "XRRRRRRRRRRRRRRRRRX",
            "XEEEEEEEEEEEEEEEEEX",
            "XRRRRRRRRRRRRRRRRRX",
            "XRRRRRRRRRRRRRRRRRX",
            "XRRRRRRRRRRRRRRRRRX",
            "XRRRRRRRRRRRRRRRRRX",
            "XDDDDDDDDDDDDDDDDDX",
            "XXXXXXXXXXXXXXXXXXX"
    };

    // Collections pour stocker les blocs
    private HashSet<block> buissonblocks = new HashSet<>();
    private HashSet<block> eaublocks = new HashSet<>();
    private HashSet<block> pelouseblocks = new HashSet<>();
    private HashSet<block> routeblocks = new HashSet<>();
    private HashSet<block> blockSortie = new HashSet<>();

    // Listes des entités du jeu
    private ArrayList<Joueur> List_joueurs = new ArrayList<>();
    //private ArrayList<Grenouille> grenouilles = new ArrayList<>();
    // es que faudrait pas faire une HashTAble ? comment dans clien
    private Hashtable<Integer, Grenouille> List_Grenouilles = new Hashtable<>();
    private ArrayList<Tronc> List_troncs = new ArrayList<>();
    private ArrayList<Serpent> List_Serpent = new ArrayList<>();
    private ArrayList<Alligator> List_alligators = new ArrayList<>();

    // Images des blocs
    private Image buissonImage = new ImageIcon(getClass().getResource("Frogger_Img/buisson.png")).getImage();
    private Image eauImage = new ImageIcon(getClass().getResource("Frogger_Img/eauV2.png")).getImage();
    private Image pelouseImage = new ImageIcon(getClass().getResource("Frogger_Img/pelouse.png")).getImage();
    private Image routeImage = new ImageIcon(getClass().getResource("Frogger_Img/pelouse.png")).getImage();
    private Image sortieImage = new ImageIcon(getClass().getResource("Frogger_Img/nenuphar2.png")).getImage();

    // Taille d'une case en pixels
    private int tileSize = 32;
    private int rowCount = tileMap.length;
    private int columnCount = tileMap[0].length();

    public plateau() {
        setFocusable(true);
        requestFocusInWindow();
        addKeyListener(this);
        loadMap();
    }

    private void loadMap() {
        for (int r = 0; r < rowCount; r++) {
            for (int c = 0; c < columnCount; c++) {
                char tile = tileMap[r].charAt(c);
                int x = c * tileSize;
                int y = r * tileSize;

                switch (tile) {
                    case 'X':
                        buissonblocks.add(new block(buissonImage, x, y, tileSize, tileSize));
                        break;
                    case 'E':
                        eaublocks.add(new block(eauImage, x, y, tileSize, tileSize));
                        break;
                    case 'P':
                        pelouseblocks.add(new block(pelouseImage, x, y, tileSize, tileSize));
                        break;
                    case 'R':
                        routeblocks.add(new block(routeImage, x, y, tileSize, tileSize));
                        break;
                    case 'S':
                        blockSortie.add(new block(sortieImage, x, y, tileSize, tileSize));
                        break;
                }
            }
        }
        // ajout de la grenouille au plateaux
        ajoutGrenouille(6,12); // on la fait spwan par rapport à des cases

        //this.joueur= new Joueur("j1",0,getGrenouille(1),1);

        ajoutTronc(12, 5, 1);
        ajoutTronc(4, 6, 1);
        ajoutTronc(6, 11, 1); // Ajoute un troisième tronc si besoin

        for (Tronc t : List_troncs) {
            t.ActivationTronc();
        }

        //ajout de la tondeuse
        ajoutSerpent(9,14,1);
        ajoutSerpent(7,7,1);
        /*for (Serpent t : List_Serpent) {
            t.ActivationTondeuse();
        }*/
        ajoutAlligator(3,11,1);
        ajoutAlligator(12,6,1);
        /*for (Alligator al : List_alligators) {
            al.ActivationAlligator();
        }*/

        //grenouille.gererMultiTroncs(List_troncs);
    }

    public void ajoutGrenouille(int x, int y) {
        for(int i =0 ; i<List_joueurs.size();i++) {
            grenouilles.add(new Grenouille(x, y, this));
            repaint();
        }
    }
    // on ajoute a notre plateau tout les grenouilles dispo donc
    // depuis client on apelle cette méthode qui ajoute nos grenouilles au plateau
    public void ajoutGrenoulles(Hashtable<Integer, Grenouille> grenouilles)
    {
        this.List_Grenouilles = grenouilles; // ajout a notre liste les grenouilles
    }
    public void ajoutTronc(int x, int y, int direction) {
        List_troncs.add(new Tronc(x * tileSize, y * tileSize, this, direction, 1,
                new ImageIcon(getClass().getResource("./Frogger_Img/troncGauche.png")).getImage()));
        repaint();
    }

    public void ajoutSerpent(int x, int y, int direction) {
        Serpent s = new Serpent(x * tileSize, y * tileSize, this, direction, 1);
        List_Serpent.add(s);
        repaint();
    }

    public void ajoutAlligator(int x, int y, int direction) {
        Alligator ali = new Alligator(x * tileSize, y * tileSize, this, direction, 1);
        List_alligators.add(ali);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (block b : buissonblocks) g.drawImage(b.image, b.x, b.y, this);
        for (block b : eaublocks) g.drawImage(b.image, b.x, b.y, this);
        for (block b : pelouseblocks) g.drawImage(b.image, b.x, b.y, this);
        for (block b : routeblocks) g.drawImage(b.image, b.x, b.y, this);
        for (block b : blockSortie) g.drawImage(b.image, b.x, b.y, this);

        for (Tronc t : List_troncs) g.drawImage(t.getImage(), t.getX(), t.getY(), this);
        for (Serpent s : List_Serpent) g.drawImage(s.getImage(), s.getX(), s.getY(), this);
        for (Alligator a : List_alligators) g.drawImage(a.getImage(), a.getX(), a.getY(), this);
        //for (Grenouille gr : grenouilles) g.drawImage(gr.getImage(), gr.getX(), gr.getY(), this);
        // Parcourir toutes les grenouilles et les dessiner

        for (Grenouille grenouille : List_Grenouilles.values()) {
            if (grenouille.getImage() != null) {
                g.drawImage(grenouille.getImage(), grenouille.getX() * tileSize, grenouille.getY() * tileSize, this);
            }
        }

        //AJOUTER ICI LES METHODES DE COLLISION

    }
    // INTERACTION ENTRE LES BLOCS
    // Gestion buisson vs grenouille
    public boolean collisionBuisson() {
        for (Grenouille grenouille : grenouilles) {
            int frogX = grenouille.getX();
            int frogY = grenouille.getY();
            for (block b : buissonblocks) {
                // On suppose que b.getX() est en pixels, alors on convertit en cases
                int blockX = b.getX() / tileSize;
                int blockY = b.getY() / tileSize;
                if (frogX == blockX && frogY == blockY) {
                    return true;
                }
            }
        }
        return false;
    }
    // GESTION DE EAU VS GRENOUILLE
    // ajout joueur en paramètre gère plusieurs joueur 01/04
    public boolean collisionSortie(ArrayList<Joueur> lstJ) {
        for (Joueur j : lstJ) {  // On parcourt tous les joueurs
            int frogX = j.getGrenouille().getX();
            // A CHANGER CA MTN DANS LA HASTABLE C GERER CA DONC JUSTE A PARCOURIR LA HASHTABLE
            int frogY = j.getGrenouille().getY();

            for (block b : blockSortie) {  // On parcourt tous les blocs de sortie
                int blockX = b.getX() / tileSize;
                int blockY = b.getY() / tileSize;

                if (frogX == blockX && frogY == blockY) {
                    return true;  // Collision détectée !
                }
            }
        }
        return false;  // Aucune grenouille n'a atteint la sortie
    }

    public boolean collisionEau() {
        for(Grenouille grenouille: grenouilles) {
            int frogX = grenouille.getX();
            int frogY = grenouille.getY();
            for (block b : eaublocks) {
                int blockX = b.getX() / tileSize;
                int blockY = b.getY() / tileSize;
                if (frogX == blockX && frogY == blockY) {
                    return true;
                }
            }
        }
        return false;
    }


    public boolean isFrogOnLog() {
        if (grenouilles == null) return false;
        for (Grenouille grenouille : grenouilles) {
            int frogX = grenouille.getBlock().getX() / tileSize;
            int frogY = grenouille.getBlock().getY() / tileSize;
            for (Tronc t : List_troncs) {
                // Convertir les coordonnées du tronc (en pixels) en cases
                int logX = t.getX() / tileSize;
                int logY = t.getY() / tileSize;
                if (frogX == logX && frogY == logY) {
                    return true;
                }
            }
        }
        return false;
    }

    // Détection des touches pour déplacer les grenouilles
    @Override
    public void keyPressed(KeyEvent e) {
        if (toucheEnfoncee) {
            return; // Bloque le mouvement si collision ou touche enfoncée
        }
        toucheEnfoncee = true;
        int key = e.getKeyCode();

        for (Grenouille grenouille : grenouilles) {
            int ancienX = grenouille.getX() / tileSize;
            int ancienY = grenouille.getY() / tileSize;

            switch (key) {
                case KeyEvent.VK_Z:
                    grenouille.updateVelocity('H');
                    break;
                case KeyEvent.VK_S:
                    grenouille.updateVelocity('B');
                    break;
                case KeyEvent.VK_Q:
                    grenouille.updateVelocity('G');
                    break;
                case KeyEvent.VK_D:
                    grenouille.updateVelocity('D');
                    break;
            }

            grenouille.move();

            if (collisionBuisson()) {
                System.out.println("Collision avec un buisson !");
                grenouille.revertPosition(); // Revenir à l'ancienne position
            } else if (collisionEau()) {
                if (!isFrogOnLog()) {
                    System.out.println("Grenouille dans l'eau et non sur un tronc ! Respawn.");
                    grenouille.setEnCollision(true);
                    grenouille.setX(6);
                    grenouille.setY(12);
                    System.out.println("Nouvelle position après respawn : X: " + grenouille.getBlock().getX() + ", Y: " + grenouille.getBlock().getY());
                    grenouille.setEnCollision(false);
                } else {
                    System.out.println("Grenouille sur tronc, elle ne meurt pas !");
                }
            } else if (collisionSortie(List_joueurs)) {
                System.out.println("Grenouille sur la sortie : score++ et respawn");
                grenouille.setX(6);
                grenouille.setY(12);
                grenouille.updateImgGrenouille();
            }
        }
        repaint();
    }
    public void setGrenouilles(Hashtable<Integer, Grenouille> grenouilles) {
        this.grenouilles.clear(); // enleve les anciennes grenouilles
        this.grenouilles.addAll(grenouilles.values()); // met a jours l'affichage
        repaint();
    }


    public int getTileSize() {
        return tileSize;
    }

    public void setTileSize(int tileSize) {
        this.tileSize = tileSize;
    }

    @Override public void keyReleased(KeyEvent e) { toucheEnfoncee = false; }
    @Override public void keyTyped(KeyEvent e) {}
}

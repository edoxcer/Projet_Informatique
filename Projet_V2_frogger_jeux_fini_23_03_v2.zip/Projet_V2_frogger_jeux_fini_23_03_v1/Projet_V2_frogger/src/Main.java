import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Frogger Multijoueur");
        plateau gamePanel = new plateau();  // Passe le client au plateau pas logique ?
        frame.add(gamePanel);
        frame.setSize(640, 640);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }
}

// quand la grenouille meurt il faut la tp  au spawn
// quand la grenouille est hors de bordure on la tp au spawn
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Hashtable;

class client {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private JFrame frame;
    private final Hashtable<Integer, Grenouille> grenouilles = new Hashtable<>();
    private int clientId;
    private plateau plateau;
    private Joueur joueurs;
    private ArrayList<Joueur> Lesjoueurs = new ArrayList<>();

    public client() {
        setupConnection();
        setupGUI();
        // ici c'est linitialisation des client
    }

    private void setupConnection() {
        try {
            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            System.out.println("Entrez le nombre de joueurs : ");
            BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
            int nbJoueurs = Integer.parseInt(consoleReader.readLine());

            clientId = Integer.parseInt(in.readLine()); // on met un id au client que on associe au joueurs et ajouter dans une liste de joueurs
            // ce qui vas nous permettre de dans la Hashtable de savoir quel joueur a quelle int et donc quelle grenouille
            // J1 = id 1 = client 1 = Grnouille 1

            for (int i = 0; i < nbJoueurs; i++) {
                int joueurId = Integer.parseInt(in.readLine()); // Lire l'ID du joueur depuis le serveur
                Joueur j = new Joueur(joueurId);
                Lesjoueurs.add(j);
            }

            int startX = 5;
            // Exemple de position de départ
            int startY = 12;
            for (Joueur joueur : Lesjoueurs) {
                Grenouille grenouille = new Grenouille(startX, startY);
                grenouilles.put((int)joueur.getId(), grenouille);
                startX += 3;
                startY += 3;// Espacement entre les grenouilles
            }



        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupGUI() {
        frame = new JFrame("Frogger Multijoueur");
        plateau = new plateau();
        plateau.setPreferredSize(new Dimension(640, 640));

        // on peut ici ajouter les grenouilles au plateau ou alors mettre la liste des joueurs en param ?
        plateau.ajoutGrenoulles(grenouilles);
        frame.add(plateau);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Détection des touches pour le déplacement
        frame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                char direction = ' ';
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_Z: direction = 'H'; break;
                    case KeyEvent.VK_S: direction = 'B'; break;
                    case KeyEvent.VK_Q: direction = 'G'; break;
                    case KeyEvent.VK_D: direction = 'D'; break;
                }
                if (direction != ' ') {
                    sendMove(direction);
                }
            }
        });
    listenToServer();
    }

    private void sendMove(char move) {
        out.println(move);
    }

    private void listenToServer() {
        new Thread(() -> {
            try {
                while (true) {
                    String response = in.readLine();
                    if (response == null) break;
                    updatePositions(response);
                    plateau.repaint();

                }
            } catch (IOException e) {
                System.out.println("Déconnexion du serveur");
            }
        }).start();
    }


    private void updatePositions(String data) {
        String[] playerData = data.split(";");

        grenouilles.clear(); // Vider la liste pour refléter les nouvelles positions reçues du serveur

        for (String entry : playerData) {
            String[] parts = entry.split(",");
            if (parts.length == 3) {
                int id = Integer.parseInt(parts[0]);
                int x = Integer.parseInt(parts[1]);
                int y = Integer.parseInt(parts[2]);

                Grenouille grenouille = grenouilles.get(id);
                if (grenouille == null) {
                    grenouille = new Grenouille(x, y);
                    grenouilles.put(id, grenouille);
                } else {
                    grenouille.setX(x);
                    grenouille.setY(y);
                }
            }
        }

        // S'assurer que le plateau a bien toutes les grenouilles
        plateau.setGrenouilles(grenouilles); // faux je pense a revoir
        plateau.repaint();
    }


    public static void main(String[] args) {
        int nbJoeuurs = 2;
        for (int i =0 ; i<nbJoeuurs;i++)
        {
            // on crée ici le nb de client en fonction du nb de joueurs
        }

    }
}

import java.io.*;
import java.net.*;

public class FrogerClient {
    static final int PORT = 8080;

    public static void main(String[] args) {
        String host = "localhost";
        try (Socket socket = new Socket(host, PORT);
             ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
             BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Connexion au serveur réussie.");

            // Lire le message du serveur (demande de pseudo)
            System.out.println(((Messages) input.readObject()).getMessage());

            // Envoi du pseudo
            System.out.print("Entrez votre pseudo : ");
            String pseudo = consoleInput.readLine();
            output.writeObject(new Messages(pseudo, pseudo));

            // Thread pour recevoir les messages du serveur
            Thread receptionThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while (true) {
                            Messages message = (Messages) input.readObject();
                            System.out.println("[" + message.getPseudo() + "] " + message.getMessage());
                        }
                    } catch (IOException | ClassNotFoundException e) {
                        System.err.println("Connexion au serveur perdue.");
                    }
                }
            });

            // Lancement du thread
            receptionThread.start();

            // Lecture et envoi des messages
            String message;
            while (true) {
                System.out.print("> ");
                message = consoleInput.readLine();
                output.writeObject(new Messages(pseudo, message));

                if (message.equalsIgnoreCase("END")) {
                    break;
                }
            }

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erreur client: " + e.getMessage());
        }
    }
}


import  java.awt.*;
// chaque case de notre plateau est un block qui a des images.
public class block
{
    int x; // en pixel ?
    int y;
    int width;
    int height;
    Image image;

    // cst avec param
    public block(Image image,int x,int y,int width,int height)
    {
        this.image = image;;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    // cst par clonage
    public block(block block)
    {
        this.image = block.image;
        this.x = block.x;
        this.y = block.y;
        this.width = block.width;
        this.height = block.height;

    }
    public void setX_Y(int x,int y)
    {
        this.x = x;
        this.y = y;
    }
    public void setImage(Image image)
    {
        this.image = image;
    }
    public  Image getImage(){return this.image;}


    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
    public int getX() {return x;}
    public int getY() {return y;}
    public void setX(int x) {this.x = x;}
    public void setY(int y) {this.y = y;}

}

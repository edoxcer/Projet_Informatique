import java.io.*;
import java.net.*;
import java.util.Hashtable;

class serveur {
    private static final int PORT = 12345;
    private static final Hashtable<Integer, Grenouille> grenouilleHashSet = new Hashtable<>();
    private static final Hashtable<Integer, PrintWriter> clientOutputs = new Hashtable<>();
    private static int clientIdCounter = 1;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur en attente de connexions...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket, clientIdCounter).start();
                clientIdCounter++;
                System.out.println("Nouveau client connecté ! sont ID : "+ clientIdCounter);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;
        private int clientId;
        private PrintWriter out;

        public ClientHandler(Socket socket, int clientId) {
            this.socket = socket;
            this.clientId = clientId;
        }

        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                // Assigner l'ID au client
                out.println(clientId);

                // Ajouter la grenouille du client
                grenouilleHashSet.put(clientId, new Grenouille(5, 5)); // Position initiale
                clientOutputs.put(clientId, out);

                // Lire les messages du client
                String message;
                while ((message = in.readLine()) != null) {
                    processMessage(clientId, message);
                }

            } catch (IOException e) {
                System.out.println("Client " + clientId + " déconnecté.");
            } finally {
                clientOutputs.remove(clientId);
                grenouilleHashSet.remove(clientId);
            }
        }

        /*Rôle : Met à jour la position d'une grenouille en fonction d'un message reçu d'un client.

Récupère la grenouille associée à l'ID du client dans grenouilleHashSet.

Vérifie si la grenouille existe, puis interprète le message (Z, S, Q, D).

Appelle deplacer(dx, dy) pour mettre à jour la position.

Envoie la mise à jour à tous les clients via envoyerPositions().*/
        private void processMessage(int id, String message) {
            Grenouille grenouille = grenouilleHashSet.get(id);
            if (grenouille != null) {
                switch (message) {
                    case "Z": grenouille.deplacer(0, -1); break;
                    case "S": grenouille.deplacer(0, 1); break;
                    case "Q": grenouille.deplacer(-1, 0); break;
                    case "D": grenouille.deplacer(1, 0); break;
                }
            }
            envoyerPositions();
        }

        /*
        * Rôle : Envoie à tous les clients les positions mises à jour de chaque grenouille.

Construit une chaîne de positions (id,x,y;id,x,y;...).

Envoie la chaîne à tous les clients via leurs PrintWriter.

*/
        private void envoyerPositions() {
            StringBuilder sb = new StringBuilder();
            for (int id : grenouilleHashSet.keySet()) {
                Grenouille g = grenouilleHashSet.get(id);
                g.updateImgGrenouille();
                sb.append(id).append(",").append(g.getX()).append(",").append(g.getY()).append(";");
            }
            String positions = sb.toString();
            for (PrintWriter writer : clientOutputs.values()) {
                writer.println(positions);
            }
        }
    }
}

import java.util.ArrayList;
import java.util.List;
public class Mode_Cooperatif {
    private List<Joueur> lesJoueurs;
    private plateau jeu;
    private int scoreGlobal;//score patagé par tous les joueurs


    public Mode_Cooperatif(List<Joueur> joueurs, plateau jeu) {
        this.lesJoueurs = joueurs;
        this.jeu = jeu;
        this.scoreGlobal = 0;
    }
    public int getScoreGlobal() {
        return scoreGlobal;
    }
    public void gestionScore()
    {
        for(Joueur joueur : lesJoueurs) {
           /* if (jeu.collisionSortie(joueur))
            {
                scoreGlobal += 1;
            }*/
        }
    }
}


import java.awt.*;
import java.util.HashSet;
import javax.swing.ImageIcon;

public class Grenouille {
    //declaration de attributs de la grenouille

    private int x;
    private int y;
    private volatile char direction;
    private Image image;
    private int score;
    private Point postion;
    private Tronc tronc;
    private  final int  tileSize = 32;
    private block block;
    private plateau terrain;
    // diff images de la grenouille face ect
    private Image image_H;
    private Image image_B;
    private Image image_G;
    private Image image_D;
    private boolean enCollision = false;


    //faire class tronc
    //private Image image_gagner;
    //private HashSet<Tronc> listeTronc;
    //private Tronc tronc;

    // pouquoi utiliser la velocié ?
    private int i;
    private int velocityX = 0;
    private int velocityY = 0;
    private int prevX, prevY;

    public Grenouille(int posX,int posY,plateau m) {
        x = posX;
        y = posY;
        image_H = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleHaut.png")).getImage();
        image_B = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleBas.png")).getImage();
        image_G = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleGauche.png")).getImage();
        image_D = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleDroite.png")).getImage();
        image = image_H;
        block = new block(image, x, y, tileSize, tileSize);
        direction = 'N';
        this.terrain = m;
        //terrain.debugMap();
        this.postion = new Point(getX(), getY());
    }
    public Grenouille(Point p ,plateau m )
    {
        this.x = p.x;
        this.y = p.y;
        block = new block(image, x, y, tileSize, tileSize);
        direction = 'N';
        this.terrain = m;
        this.postion = new Point(getX(), getY());

    }
    public Grenouille(int x ,int y)
    {
        this.x = x;
        this.y = y;
        image_H = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleHaut.png")).getImage();
        image_B = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleBas.png")).getImage();
        image_G = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleGauche.png")).getImage();
        image_D = new ImageIcon(getClass().getResource("./Frogger_Img/GrenouilleDroite.png")).getImage();
        image = image_H;
        block = new block(image, x, y, tileSize, tileSize);
        direction = 'N';
        this.postion = new Point(x, y);
    }

    //gère les images selon la direction
    /*public void updateVelocity( char c) {
        if (c == 'H') {
            this.velocityX = 0;
            this.velocityY = -1;
            this.image = image_H;
        }
        else if (c == 'B') {
            this.velocityX = 0;
            this.velocityY = 1;
            this.image = image_B;
        }
        else if (c == 'G') {
            this.velocityX = -1;
            this.velocityY = 0;
            this.image = image_G;
        }
        else if (c == 'D') {
            this.velocityX = 1;
            this.velocityY = 0;
            this.image = image_D;
        }
        block.setImage(this.image);
    }*/
    // Gère les images selon la direction
    public void updateVelocity(char c) {
        switch (c) {
            case 'H': image = image_H; break;
            case 'B': image = image_B; break;
            case 'G': image = image_G; break;
            case 'D': image = image_D; break;
        }
        block.setImage(image);
    }


    /*public void move() {

        //System.out.println("AncienX (cases) : " + this.x + ", AncienY (cases) : " + this.y);
        // Vérifie si les coordonnées sont déjà en pixels (bug probable)
        // Suppose qu'on a une grille de jeu plus petite que 32x32
        sauvegarderPosition();
        if (this.x > 32 || this.y > 32) {
            this.x /= tileSize;  // Convertit en cases
            // cela veut dire qu'il faut convert tous nos pixels en cases
            this.y /= tileSize;
        }
        this.x += this.velocityX;
        this.y += this.velocityY;
        System.out.println("Nouvelle position cases -> X: " + this.x + ", Y: " + this.y);
        this.block.setX_Y(this.x * tileSize, this.y * tileSize); // Conversion correcte en pixels
        updateImgGrenouille();

        //System.out.println("Position en pixels -> X: " + this.block.getX() + ", Y: " + this.block.getY());

    }*/
    public void move() {
        sauvegarderPosition();

        // Mise à jour des coordonnées (en cases)
        this.x += this.velocityX;
        this.y += this.velocityY;

        System.out.println("Nouvelle position cases -> X: " + this.x + ", Y: " + this.y);

        // Mise à jour du bloc visuel (converti en pixels)
        this.block.setX_Y(this.x * tileSize, this.y * tileSize);
        updateImgGrenouille();
    }

    public void deplacer(int dx, int dy) {
        sauvegarderPosition(); // Sauvegarde la position avant de bouger
        this.x += dx;
        this.y += dy;
        updateImgGrenouille();
    }


    // Convertit en cases
    public void Position_Case_Grenouille()
    {
        if (this.x > 32|| this.y >32)
        {
            this.x /= tileSize;
            this.y /= tileSize;
        }
    }

    public block getBlock()
    {
        return this.block;
    }

    public void updateImgGrenouille() {
        // Mettre à jour la position du block visuel lié à la grenouille
        block.setX_Y(this.x * tileSize, this.y * tileSize);

        // Met à jour l'image selon la direction
        switch (this.direction) {
            case 'H':
                image = image_H;
                break;
            case 'B':
                image = image_B;
                break;
            case 'G':
                image = image_G;
                break;
            case 'D':
                image = image_D;
                break;
        }
        block.setImage(image);
    }



    // Méthode appelée avant de déplacer la grenouille
    public void sauvegarderPosition() {
        prevX = x;
        prevY = y;
    }
    // Méthode pour annuler le déplacement (retour à la position précédente)
    public void revertPosition() {
        x = prevX;
        y = prevY;
        updateImgGrenouille();
    }
    public void gererMultiTroncs(java.util.List<Tronc> troncs) {
        boolean surUnTronc = false;

        for (Tronc t : troncs) {
            int frogX = this.x;
            int frogY = this.y;

            for (int i = 0; i < 2; i++) {
                int blocX = (t.getX() / tileSize) + i;
                int blocY = t.getY() / tileSize;

                if (frogX == blocX && frogY == blocY) {
                    if (t.getDirection() == 1) {
                        this.x += 1;
                    } else {
                        this.x -= 1;
                    }
                    surUnTronc = true;
                    break;
                }
            }
            if (surUnTronc) break;
        }

        if (surUnTronc) {
            this.updateImgGrenouille();
        }
    }



    public boolean isEnCollision() {
        return enCollision;
    }
    public void setEnCollision(boolean enCollision) {
        this.enCollision = enCollision;
    }
    public int getX() {
        return this.x;  // doit rester en cases
    }

    public int getY() {
        return this.y;
    }

    public void setX(int i)
    {
        this.x=i;
    }

    public void setY(int j)
    {
        this.y=j;
    }

    public void setMap(plateau p)
    {
        this.terrain=p;
    }

    public int getScore() {
        return score;
    }
    void setScore(int score) {
        this.score = score;
    }
    public Point getPosition() {
        return this.postion;
    }
    public void setPosition(Point p) {
        this.postion = p;
    }
    public void setPlateau(plateau p) {
        this.terrain = p;
    }


    public Image getImage() {
        return  this.image;
    }
}


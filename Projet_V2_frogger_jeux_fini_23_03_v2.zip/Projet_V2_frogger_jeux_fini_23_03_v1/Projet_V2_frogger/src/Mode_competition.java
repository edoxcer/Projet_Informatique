import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

class Mode_competition {
    private List<Joueur> lesJoueurs;
    private plateau jeu;

    public Mode_competition(List<Joueur> joueurs, plateau jeu) {
        this.lesJoueurs = joueurs;
        this.jeu = jeu;
    }



    public void gestionScore()
    {
        /*if (jeu.collisionSortie(lesJoueurs))
            {
                lesJoueurs.
                //System.out.println("Score de "+joueur.getPseudo()+" : "+joueur.getScore());
            }*/
    }
}


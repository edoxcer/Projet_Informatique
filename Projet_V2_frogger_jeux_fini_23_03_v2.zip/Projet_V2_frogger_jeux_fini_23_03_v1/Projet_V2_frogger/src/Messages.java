import java.io.Serializable;

public class Messages implements Serializable {
    private static final long serialVersionUID = 1L;
    private String pseudo;
    private String message;

    public Messages(String pseudo, String message) {
        this.pseudo = pseudo;
        this.message = message;
    }

    public String getPseudo() {
        return pseudo;
    }

    public String getMessage() {
        return message;
    }
}

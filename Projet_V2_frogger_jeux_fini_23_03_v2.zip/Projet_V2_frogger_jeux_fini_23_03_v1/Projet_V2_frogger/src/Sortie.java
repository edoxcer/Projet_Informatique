
public class Sortie {
   private block blockSortie;
   private Grenouille grenouilleSortie;
   private int Joueur;
    public Sortie(block blockSortie , Grenouille grenouilleSortie) {
        this.blockSortie = blockSortie;
        this.grenouilleSortie = grenouilleSortie;
    }


    // on vien comparer la pos de la grenouille et du block sortie si c valide on return true
    public  boolean SortieValide()
    {
        int Frogx = grenouilleSortie.getX();
        int Frogy = grenouilleSortie.getY();
        int Blockx = blockSortie.getX();
        int Blocky = blockSortie.getY();
        if (Frogx == Blockx && Frogy == Blocky)
        {
            return true;
        }
        else{
            return  false;
        }
    }

}

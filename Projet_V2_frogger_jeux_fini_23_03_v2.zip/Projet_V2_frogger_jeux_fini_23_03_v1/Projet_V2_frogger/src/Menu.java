import java.util.Scanner;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
public class Menu {
    private Mode_competition mComp;
    private Mode_Cooperatif mCoop;
    private plateau plateau;
    private List<Joueur> joueurs;

    public Menu(plateau plateau, List<Joueur> joueurs) {
        this.plateau = plateau;
        this.joueurs = joueurs;
        gestionMenu();
    }
    public Menu() {
        gestionMenu();
    }

    public void gestionMenu(){
        System.out.println("Sélectionner un mode de jeu");
        System.out.println("1-Mode Competition \n 2-Mode Cooperatif");
        Scanner scanner = new Scanner(System.in);
        int choix = scanner.nextInt();
        switch (choix){
            case 1:
                mComp = new Mode_competition(joueurs, plateau);
                mComp.gestionScore();
                System.out.println("Score global : " + mCoop.getScoreGlobal());
                break;
            case 2:
                mCoop= new Mode_Cooperatif(joueurs, plateau);
                mCoop.gestionScore();
                System.out.println("Score global : " + mCoop.getScoreGlobal());
                break;
            default:
                System.out.println("Veuillez choisir une option valide");
                break;
        }
    }
}

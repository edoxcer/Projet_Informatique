import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class FrogerServeur {
    private static final int PORT = 8080;
    private static final int MAX_CLIENTS = 10;
    private static List<ClientHandler> clients = new ArrayList<>();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur en attente de connexions sur le port " + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nouveau client connecté: " + clientSocket);

                if (clients.size() < MAX_CLIENTS) {
                    ClientHandler clientHandler = new ClientHandler(clientSocket);
                    clients.add(clientHandler);
                    clientHandler.start();
                } else {
                    System.out.println("Capacité maximale atteinte, refus de connexion.");
                    clientSocket.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static synchronized void removeClient(ClientHandler clientHandler) {
        clients.remove(clientHandler);
    }

    public static synchronized void BroaCast(Messages message, ClientHandler clientHandler_sender) {
        for (ClientHandler client : clients) {
            if (client != clientHandler_sender) {
                client.sendMessage(message);
            }
        }
    }
}

class ClientHandler extends Thread {
    private Socket socket;
    private ObjectOutputStream output;
    private ObjectInputStream input;
    private String pseudo;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            output = new ObjectOutputStream(socket.getOutputStream());
            input = new ObjectInputStream(socket.getInputStream());

            // Demande le pseudo
            output.writeObject(new Messages("Serveur", "Entrez votre pseudo : "));
            pseudo = ((Messages) input.readObject()).getMessage();
            System.out.println(pseudo + " s'est connecté.");

            // Diffuse l'entrée du client
            FrogerServeur.BroaCast(new Messages("Serveur", pseudo + " a rejoint le chat !"),this);

            Messages message;
            while ((message = (Messages) input.readObject()) != null) {
                if (message.getMessage().equalsIgnoreCase("END")) {
                    break;
                }
                FrogerServeur.BroaCast(message,this);
            }

            System.out.println(pseudo + " s'est déconnecté.");
            FrogerServeur.BroaCast(new Messages("Serveur", pseudo + " a quitté le chat."),this);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erreur client: " + e.getMessage());
        } finally {
            try {
                input.close();
                output.close();
                socket.close();
                FrogerServeur.removeClient(this);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void sendMessage(Messages message) {
        try {
            output.writeObject(message);
        } catch (IOException e) {
            System.err.println("Erreur d'envoi de message à " + pseudo);
        }
    }
}

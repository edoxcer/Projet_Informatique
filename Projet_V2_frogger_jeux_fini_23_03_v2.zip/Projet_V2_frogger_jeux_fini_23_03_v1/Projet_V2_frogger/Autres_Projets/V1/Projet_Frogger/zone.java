import java.util.ArrayList;

public class zone {
    private String[][] tab;
    private int taille_pl[] = new int[2];
    private ArrayList<Obstacles> obstaclesList = new ArrayList<>();

    public zone(int tailleI, int tailleJ) {
        this.taille_pl[0] = tailleI; // hauteur
        this.taille_pl[1] = tailleJ; // largeur
        this.tab = new String[tailleI][tailleJ];

        // Initialisation du plateau : bordures et espaces internes
        for (int i = 0; i < tailleI; i++) {
            for (int j = 0; j < tailleJ; j++) {
                if (isBordure(i, j)) {
                    tab[i][j] = "█"; // bordure
                } else {
                    tab[i][j] = " "; // espace vide
                }
            }
        }
    }

    // Ajoute un obstacle et l'affiche sur la grille
    public void addObstacle(Obstacles ob) {
        obstaclesList.add(ob);
        tab[ob.getX()][ob.getY()] = ob.getSymbole();
    }

    // Renvoie vrai si (i, j) est sur la bordure
    public boolean isBordure(int i, int j) {
        return (i == 0 || i == taille_pl[0] - 1 || j == 0 || j == taille_pl[1] - 1);
    }

    // Met à jour le plateau en effaçant l'ancienne position des obstacles et en les plaçant à leur nouvelle position
    public void updatePlateau() {
        // Effacer l'ancienne position des obstacles (en utilisant oldX et oldY)
        for (Obstacles ob : obstaclesList) {
            if (!isBordure(ob.getOldX(), ob.getOldY())) {
                tab[ob.getOldX()][ob.getOldY()] = " ";
            }
        }
        // Placer les obstacles à leur nouvelle position
        for (Obstacles ob : obstaclesList) {
            tab[ob.getX()][ob.getY()] = ob.getSymbole();
        }
    }

    // Affiche le plateau
    public void affichage_plateaux() {
        for (int i = 0; i < taille_pl[0]; i++) {
            for (int j = 0; j < taille_pl[1]; j++) {
                System.out.print(tab[i][j]);
            }
            System.out.println();
        }
    }
    //suprimme le tableau
    public  void delete_tab()
    {
        for (int i = 0; i < getTailleI(); i++) {
            for (int j = 0; j < getTailleJ(); j++) {
                tab[i][j] = " ";
            }
        }
    }

    public int getTailleI() { return taille_pl[0]; }
    public int getTailleJ() { return taille_pl[1]; }
}

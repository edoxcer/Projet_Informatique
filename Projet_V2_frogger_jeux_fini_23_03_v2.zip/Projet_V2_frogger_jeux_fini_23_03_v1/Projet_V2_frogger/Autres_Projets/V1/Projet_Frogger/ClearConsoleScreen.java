public class ClearConsoleScreen {
    public static void main(String[] args) {
        System.out.prinln("fjebbbbbbbbbbbbbbbbf");
        System.out.print("Tout sera effacé de la console");
        System.out.print("\033[H\033[2J"); // Code d'échappement pour effacer la console
        System.out.flush(); // Assure que tout est imprimé immédiatement
    }
}
import java.util.Random;

public class Obstacles {
    private String symbole;
    private zone Zone;
    private int x, y;
    private int oldX, oldY; // anciennes coordonnées

    public Obstacles(String symbole, zone z) {
        this.symbole = symbole;
        this.Zone = z;
        placeOB();
    }

    // Place l'obstacle à une position aléatoire (hors bordures)
    public void placeOB() {
        Random rand = new Random();
        int newX, newY;
        do {
            newX = rand.nextInt(Zone.getTailleI());
            newY = rand.nextInt(Zone.getTailleJ());
        } while (Zone.isBordure(newX, newY));
        this.x = newX;
        this.y = newY;
        this.oldX = x;
        this.oldY = y;
    }

    // Déplace l'obstacle de gauche à droite
    public void move() {
        // Sauvegarde l'ancienne position
        oldX = x;
        oldY = y;

        // Déplacement horizontal (même ligne, y + 1)
        int newY = y + 1;
        // Si l'obstacle atteint la bordure droite, on le ramène à la première colonne interne (colonne 1)
        if (newY >= Zone.getTailleJ() - 1) {
            newY = 1;
        }
        y = newY;
    }

    // Getters
    public int getX() { return x; }
    public int getY() { return y; }
    public int getOldX() { return oldX; }
    public int getOldY() { return oldY; }
    public String getSymbole() { return symbole; }
}



public class grenouille {
    private int x,y;
    private char symbole;
}


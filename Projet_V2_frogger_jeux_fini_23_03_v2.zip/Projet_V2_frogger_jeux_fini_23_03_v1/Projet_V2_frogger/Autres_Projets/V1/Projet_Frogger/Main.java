public class Main {
    public static void main(String[] args) {

        zone gameZone = new zone(10, 20);
        Obstacles ob1 = new Obstacles("X", gameZone);

        // Ajoute l'obstacle au plateau
        gameZone.addObstacle(ob1);

        // Affiche le plateau une première fois (plateau fixe avec bordures)
        gameZone.affichage_plateaux();

        // Boucle de mise à jour : seuls les obstacles se déplacent
        for (int t = 0; t < 10; t++) {
            ob1.move();
            gameZone.delete_tab();
            // Faire une méthode qui supprime le tab et le re affiche avec le déplacement des obs.
            gameZone.affichage_plateaux();
        }
    }



}

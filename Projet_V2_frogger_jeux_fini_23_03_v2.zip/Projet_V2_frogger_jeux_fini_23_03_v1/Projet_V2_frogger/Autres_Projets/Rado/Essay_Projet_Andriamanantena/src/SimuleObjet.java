import java.util.ArrayList;
import java.util.HashSet;

public class SimuleObjet extends Thread{
    private HashSet<Voiture> voituresL1=new HashSet<Voiture>();
    //private ArrayList<Voiture> voituresL1=new ArrayList<>();
    private HashSet<Tronc> troncs=new HashSet<Tronc>();
    private Map map;
    private int vitesse;
    private boolean encours;

    public SimuleObjet(Map m,int v){
        this.map=m;
        this.vitesse=v;
        this.encours=true;
        /*voituresL1.add(new VoitureBleu(18, map, 0, vitesse));
        voituresL1.add(new VoitureJaune(18, map, 0, vitesse));
        voituresL1.add(new VoitureBleu(18, map, 0, vitesse));
        voituresL1.add(new VoitureVert(18, map, 0, vitesse));*/
    }

    public HashSet<Voiture> getVoituresL1()
    {
        return voituresL1;
    }

    public void run()
    {
        while(encours)
        {
            voituresL1.add(new VoitureBleu(18, map, 1, vitesse));
            voituresL1.add(new VoitureJaune(18, map, 1, vitesse));
            voituresL1.add(new VoitureVert(18, map, 1, vitesse));
                for(Voiture v: voituresL1){
                    if(v.getEncours()==true){
                        new Thread(v).start();
                        System.err.println(v+" a été lancer");
                        int r=(int)(Math.random()*10)+2;
                        try{
                            Thread.sleep(vitesse*r);
                        }catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                    else{
                        voituresL1.remove(v);
                        System.err.println(v+" a été retiré");
                    }
                }
            /*for(Voiture v: voituresL1){
                if(v.getEncours()==false)
                {
                    voituresL1.remove(v);
                    System.err.println(v+" a été retiré");
                }
            }*/
            System.err.println(voituresL1.size());
        }
    }
}

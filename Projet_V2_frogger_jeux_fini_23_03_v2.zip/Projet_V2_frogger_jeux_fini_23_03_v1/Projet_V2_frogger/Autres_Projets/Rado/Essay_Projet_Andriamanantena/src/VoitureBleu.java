import javax.swing.ImageIcon;

public class VoitureBleu extends Voiture {

    public VoitureBleu(int posY, Map m, int c,int v) {
        super(posY, m, c, v);
        if(cote==1){
            this.x=-2;
            this.image=new ImageIcon(getClass().getResource("./image/voiture.png")).getImage();
            this.limite=19;
            
        }
        else{
            this.x=19;
            this.image=new ImageIcon(getClass().getResource("./image/voiture2.png")).getImage();
            this.limite=-2;
        }
        this.taille=2;
        this.block= new Block(image,x,y,tileSize*taille,tileSize);
        this.intX=x;
    }
    
}

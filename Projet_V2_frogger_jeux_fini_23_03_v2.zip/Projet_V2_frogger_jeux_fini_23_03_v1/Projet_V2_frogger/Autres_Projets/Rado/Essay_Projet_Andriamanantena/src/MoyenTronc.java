import javax.swing.ImageIcon;

public class MoyenTronc extends Tronc{
    public MoyenTronc(int posY,Map m, int c,int v){
        super(posY, m, c,v);
        //this.cote=c;
        if(cote==1){
            this.x=-5;
            this.image=new ImageIcon(getClass().getResource("./image/moyentronc.png")).getImage();
            this.limite=19;
            
        }
        else{
            this.x=19;
            this.image=new ImageIcon(getClass().getResource("./image/moyentronc2.png")).getImage();
            this.limite=-5;
        }
        //this.y=posY;
        this.taille=5;
        this.block= new Block(image,x,y,tileSize*taille,tileSize);
        //this.terrain=m;
        this.tabX=new int[taille];
        for(int i=0;i<taille;i++)
        {
            tabX[i]=x+i;
        }
    }
}

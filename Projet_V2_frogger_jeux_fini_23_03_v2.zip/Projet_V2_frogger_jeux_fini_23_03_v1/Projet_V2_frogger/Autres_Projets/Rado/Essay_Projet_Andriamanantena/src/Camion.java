import javax.swing.ImageIcon;

public class Camion extends Voiture{
    public Camion(int posY, Map m, int c,int v) {
        super(posY, m, c, v);
        if(cote==1){
            this.x=-3;
            this.image=new ImageIcon(getClass().getResource("./image/camion.png")).getImage();
            this.limite=20;
            
        }
        else{
            this.x=19;
            this.image=new ImageIcon(getClass().getResource("./image/camion2.png")).getImage();
            this.limite=-3;
        }
        this.taille=3;
        this.block= new Block(image,x,y,tileSize*taille,tileSize);
        this.intX=x;
    }
}

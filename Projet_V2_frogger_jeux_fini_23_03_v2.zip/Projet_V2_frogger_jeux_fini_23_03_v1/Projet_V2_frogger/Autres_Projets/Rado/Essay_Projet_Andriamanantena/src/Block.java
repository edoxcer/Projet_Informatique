import java.awt.*;
public class Block {
    int x;
    int y;
    int width;
    int height;
    Image image;

    /*int startX;
    int startY;
    char direction = 'H'; // H B G D
    int velocityX = 0;
    int velocityY = 0;
    int tileSize = 32;*/

    public Block(Image image, int x, int y, int width, int height) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        //this.startX = x;
        //this.startY = y;
    }

    public void set(int xx,int yy)
    {
        this.x=xx;
        this.y=yy;
    }

    public void setImage(Image i)
    {
        image=i;
    }

    /*void updateDirection(char direction) {
        char prevDirection = this.direction;
        this.direction = direction;
        updateVelocity();
        this.x += this.velocityX;
        this.y += this.velocityY;
        for (Block wall : walls) {
            if (collision(this, wall)) {
                this.x -= this.velocityX;
                this.y -= this.velocityY;
                this.direction = prevDirection;
                updateVelocity();
            }
        }
    }*/

    /*void updateVelocity( char c) {
        if (c == 'H') {
            this.velocityX = 0;
            this.velocityY = -tileSize;
        }
        else if (c == 'B') {
            this.velocityX = 0;
            this.velocityY = tileSize/4;
        }
        else if (c == 'G') {
            this.velocityX = -tileSize/4;
            this.velocityY = 0;
        }
        else if (c == 'D') {
            this.velocityX = tileSize/4;
            this.velocityY = 0;
        }
    }

    void move()
    {
        this.x=x+this.velocityX;
        this.y=y+this.velocityY;
    }

    /*public boolean collision(Block a, Block b) {
        return  a.x < b.x + b.width &&
                a.x + a.width > b.x &&
                a.y < b.y + b.height &&
                a.y + a.height > b.y;
    }

    void reset() {
        this.x = this.startX;
        this.y = this.startY;
    }*/
}

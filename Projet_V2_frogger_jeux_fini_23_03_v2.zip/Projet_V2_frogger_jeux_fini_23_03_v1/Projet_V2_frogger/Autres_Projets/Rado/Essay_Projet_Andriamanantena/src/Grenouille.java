import java.awt.Image;
import java.util.HashSet;

import javax.swing.ImageIcon;

public class Grenouille implements Runnable{
    
    private String type;
    private String nom;
    private int x;
    private int y;
    private volatile char direction;
    private boolean enVie;
    private boolean gagne;
    private Image image;
    private int tileSize = 32;
    private Block block;
    private JMap Jterrain;
    private Map terrain;
    private Image image_H;
    private Image image_B;
    private Image image_G;
    private Image image_D;
    private Image image_mort;
    private Image image_gagner;
    private HashSet<Tronc> listeTronc;
    private Tronc tronc;
    private int i;
    private int velocityX = 0;
    private int velocityY = 0;
    private int predX;
    private int score;


    public Grenouille(String n, String t,int posX,int posY,Map m)
    {
        nom=n;
        type=t;
        x=posX;
        y=posY;
        enVie=true;
        gagne=true;
        image_H=new ImageIcon(getClass().getResource("./image/Froggy_H.png")).getImage();
        image_B=new ImageIcon(getClass().getResource("./image/Froggy_B.png")).getImage();
        image_G=new ImageIcon(getClass().getResource("./image/Froggy_G.png")).getImage();
        image_D=new ImageIcon(getClass().getResource("./image/Froggy_D.png")).getImage();
        image_mort=new ImageIcon(getClass().getResource("./image/mort.png")).getImage();
        image_gagner=new ImageIcon(getClass().getResource("./image/gagner.png")).getImage();
        image=image_H;
        block= new Block(image, x, y, tileSize, tileSize);
        direction='N';
        Jterrain=null;
        this.terrain=m;
        m.ajoutGrenouille(this.x, this.y);
        //terrain.debugMap();
    }

    public int getX()
    {
        return this.x;
    }

    public int getY()
    {
        return this.y;
    }

    public void setX(int i)
    {
        this.x=i;
    }

    public void setY(int j)
    {
        this.y=j;
    }

    public void setMap(JMap m)
    {
        this.Jterrain=m;
    }

    public void run(){
        this.listeTronc=Jterrain.getTroncs();
        while(enVie && gagne)
            {   
                this.enVie=terrain.collision(x, y);
                if(this.sur_un_tronc())
                {
                    //System.err.println("sur un tronc");
                    while (true) {
                        this.predX=this.x;
                        this.x=this.tronc.getX()+i;
                        this.enVie=this.terrain.setXY_sur_eau(x, y, predX);
                        this.block.set(x, y);
                        if(direction!=Jterrain.getDirection() || this.enVie==false)
                        {
                            break;
                        }
                    }
                }
                if(direction!=Jterrain.getDirection()){
                    //System.err.println("x1= "+x+" y1= "+y);
                    updateVelocity(Jterrain.getDirection());
                    int intX=this.x+this.velocityX;
                    int intY= this.y+this.velocityY;
                    this.direction=Jterrain.getDirection();
                    int choix=terrain.move(intX, intY,velocityX,velocityY);
                    if(choix==0 || choix==1 || choix==3){
                        move();
                        //System.err.println("x3= "+x+" y3= "+y);
                        if (direction == 'H') {
                            image=image_H;
                        }
                        else if (direction == 'B') {
                            image=image_B;
                        }
                        else if (direction == 'G') {
                            image=image_G;
                        }
                        else if ( direction == 'D') {
                            image=image_D;
                        }
                        block.setImage(image);
                        block.set(x, y);
                        //terrain.debugMap();
                        if(choix==1)
                        {
                            this.enVie=false;
                        }
                        if(choix==3)
                        {
                            this.gagne=false;
                        }
                    }
                    this.direction='N';
                    Jterrain.setDirection('N');
                }
                //System.err.println("ici");
                try {
                    Thread.sleep(50); // Pause pour limiter la charge CPU
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    
                }
            }
            
            if(enVie==false){
                block.setImage(image_mort);
                System.err.println("mort");
            }
            if(gagne==false)
            {
                block.setImage(image_gagner);
            }
            //terrain.debugMap();
            //System.err.println("grenouille mort");
    }

    /*void updateVelocity( char c) {
        if (c == 'H') {
            this.velocityX = 0;
            this.velocityY = -tileSize;
        }
        else if (c == 'B') {
            this.velocityX = 0;
            this.velocityY = tileSize;
        }
        else if (c == 'G') {
            this.velocityX = -tileSize;
            this.velocityY = 0;
        }
        else if (c == 'D') {
            this.velocityX = tileSize;
            this.velocityY = 0;
        }
    }*/

    void updateVelocity( char c) {
        if (c == 'H') {
            this.velocityX = 0;
            this.velocityY = -1;
        }
        else if (c == 'B') {
            this.velocityX = 0;
            this.velocityY = 1;
        }
        else if (c == 'G') {
            this.velocityX = -1;
            this.velocityY = 0;
        }
        else if (c == 'D') {
            this.velocityX = 1;
            this.velocityY = 0;
        }
    }

    public boolean sur_un_tronc()
    {
        for(Tronc tronc: listeTronc){
            for(int i=0;i<tronc.getTaille();i++){
                if(tronc.getX()+i==this.x && tronc.getY()==this.y){
                    this.i=i;
                    this.tronc=tronc;
                    return true;
                }
            }
        }
        return false;
    }

    

    /*public boolean collision(Block a, Block b) {
        return  a.x < b.x + b.width &&
                a.x + a.width > b.x &&
                a.y < b.y + b.height &&
                a.y + a.height > b.y;
    }

    void reset() {
        this.x = this.startX;
        this.y = this.startY;
    }*/

    public void move()
    {   
        this.x=x+this.velocityX;
        this.y=y+this.velocityY;
    }


    public Block getBlock()
    {
        return this.block;
    }

}

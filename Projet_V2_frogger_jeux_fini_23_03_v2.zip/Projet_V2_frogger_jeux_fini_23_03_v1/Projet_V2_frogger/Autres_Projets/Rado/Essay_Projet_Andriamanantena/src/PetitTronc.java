import javax.swing.ImageIcon;

public class PetitTronc extends Tronc{
    /*private String type;
    private String nom;
    private int x;
    private int y;
    private int taille;
    private Image image;
    private int tileSize = 32;
    private Block block;
    private JMap Jterrain;
    private Map terrain;
    private int limite;
    private int cote;
    private int[] tabX;*/

    public PetitTronc(int posY,Map m, int c,int v){
        super(posY, m, c,v);
        //this.cote=c;
        if(cote==1){
            this.x=-2;
            this.image=new ImageIcon(getClass().getResource("./image/petit_tronc.png")).getImage();
            this.limite=19;
            
        }
        else{
            this.x=19;
            this.image=new ImageIcon(getClass().getResource("./image/petit_tronc2.png")).getImage();
            this.limite=-2;
        }
        //this.y=posY;
        this.block= new Block(image,x,y,tileSize*2,tileSize);
        this.taille=2;
        //this.terrain=m;
        this.tabX=new int[taille];
        for(int i=0;i<taille;i++)
        {
            tabX[i]=x+i;
        }
    }

    /*public int getX(){
        return this.x;
    }

    public void rouler()
    {
        if(cote==1){
            this.x++;
        }
        else{
            this.x--;
        }
    }

    public int[] getTabX()
    {
        return tabX;
    }

    public int getY(){
        return this.y;
    }

    public int getTaille(){
        return taille;
    }

    public Block getBlock()
    {
        return this.block;
    }

    @Override
    public void run() {
        while(true)
        {
            //terrain.debugMap();
            this.rouler();
            if(cote==1){
                terrain.TroncGD(x, y, taille);
                if(x>limite)
                    break;
            }
            else{
                terrain.TroncDG(x, y, taille);
                if(x<limite)
                    break;
            }
            block.set(x, y);
            try{
                Thread.sleep(1000);
            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }*/

}

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import javax.swing.*;

public class JMap extends JPanel implements ActionListener, KeyListener{




    /*public class Block {
        int x;
        int y;
        int width;
        int height;
        Image image;
    
        int startX;
        int startY;
        char direction = 'H'; // H B G D
        int velocityX = 0;
        int velocityY = 0;
    
        public Block(Image image, int x, int y, int width, int height) {
            this.image = image;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.startX = x;
            this.startY = y;
        }
    
        /*void updateDirection(char direction) {
            char prevDirection = this.direction;
            this.direction = direction;
            updateVelocity();
            this.x += this.velocityX;
            this.y += this.velocityY;
            for (Block wall : walls) {
                if (collision(this, wall)) {
                    this.x -= this.velocityX;
                    this.y -= this.velocityY;
                    this.direction = prevDirection;
                    updateVelocity();
                }
            }
        }
    
        void updateVelocity() {
            if (this.direction == 'U') {
                this.velocityX = 0;
                this.velocityY = -tileSize/4;
            }
            else if (this.direction == 'D') {
                this.velocityX = 0;
                this.velocityY = tileSize/4;
            }
            else if (this.direction == 'L') {
                this.velocityX = -tileSize/4;
                this.velocityY = 0;
            }
            else if (this.direction == 'R') {
                this.velocityX = tileSize/4;
                this.velocityY = 0;
            }
        }
    
        public boolean collision(Block a, Block b) {
            return  a.x < b.x + b.width &&
                    a.x + a.width > b.x &&
                    a.y < b.y + b.height &&
                    a.y + a.height > b.y;
        }
    
        void reset() {
            this.x = this.startX;
            this.y = this.startY;
        }
    }*/

    private int rowCount = 21;
    private int columnCount = 19;
    private int tileSize = 32;
    private int boardWidth = columnCount * tileSize;
    private int boardHeight = rowCount * tileSize;

    private String[] tileMap = {
            "BBBBBBBBBBBBBBBBBBB",
            "BBBBBBBBBBBBBBBBBBB",
            "BBBNBBBNBBBNBBBNBBB",
            "EEEEEEEEEEEEEEEEEEE",
            "EEEEEEEEEEEEEEEEEEE",
            "EEEEEEEEEEEEEEEEEEE",
            "EEEEEEEEEEEEEEEEEEE",
            "EEEEEEEEEEEEEEEEEEE",
            "EEEEEEEEEEEEEEEEEEE",
            "EEEEEEEEEEEEEEEEEEE",
            "PPPPPPPPPPPPPPPPPPP",
            "PPPPPPPPPPPPPPPPPPP",
            "PPPPPPPPPPPPPPPPPPP",
            "RRRRRRRRRRRRRRRRRRR",
            "RRRRRRRRRRRRRRRRRRR",
            "RRRRRRRRRRRRRRRRRRR",
            "RRRRRRRRRRRRRRRRRRR",
            "RRRRRRRRRRRRRRRRRRR",
            "RRRRRRRRRRRRRRRRRRR",
            "PPPPPPPPPPPPPPPPPPP",
            "PPPPPPPPPPPPPPPPPPP"
    };

    private Image buisson2;
    private Image buisson;
    private Image eau;
    private Image imageFroggy;
    private Image Map;
    private Image nenuphare;
    private Image pelouse;
    private Image route;

    private HashSet<Block> buisson2s;
    private HashSet<Block> buissons;
    private HashSet<Block> eaus;
    private HashSet<Block> nenuphares;
    private HashSet<Block> pelouses;
    private HashSet<Block> routes;
    private HashSet<Grenouille> grenouilles;
    private Grenouille Froggy;

    private Timer gameLoop;
    private boolean gameOver=false;
    private char direction;
    private Map terrain;
    private HashSet<Thread> threads;

    //private HashSet<Voiture> voitures;

    private HashSet<Voiture> voitures;

    private HashSet<Tronc> troncs;


    public JMap(HashSet<Grenouille> g,HashSet<Thread> th, Map m,Grenouille gre, HashSet<Voiture> v,HashSet<Tronc> pt){
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        setFocusable(true);

        buisson2 = new ImageIcon(getClass().getResource("/image/buisson2.png")).getImage();
        buisson = new ImageIcon(getClass().getResource("/image/buisson.png")).getImage();
        eau = new ImageIcon(getClass().getResource("/image/eau.png")).getImage();
        Map = new ImageIcon(getClass().getResource("/image/map.gif")).getImage();
        nenuphare = new ImageIcon(getClass().getResource("/image/nenuphare.png")).getImage();
        pelouse = new ImageIcon(getClass().getResource("/image/pelouse.png")).getImage();
        route = new ImageIcon(getClass().getResource("/image/route.png")).getImage();


        SimuleObjet essay=new SimuleObjet(m, 1000);
        //essay.start();
        this.terrain=m;
        loadMap();
        threads=new HashSet<Thread>();
        threads=th;
        this.direction='N';
        gameLoop = new Timer(50, this); //20fps (1000/50)
        gameLoop.start();
        this.grenouilles=g;
        this.voitures=v;
        this.troncs=pt;
        /*for (Grenouille grenouille : grenouilles) {
            grenouille.setMap(this);
        }*/
        //voiture2=new Voiture(0,terrain,0);
        this.Froggy=gre;
        this.Froggy.setMap(this);
        for(Thread t: threads)
        {
            t.start();
        }
        //this.notifyAll();

    }

    public void loadMap() {
        buisson2s = new HashSet<Block>();
        buissons = new HashSet<Block>();
        eaus  = new HashSet<Block>();
        nenuphares  = new HashSet<Block>();
        pelouses  = new HashSet<Block>();
        routes  = new HashSet<Block>();
        for (int r = 0; r < rowCount; r++) {
            for (int c = 0; c < columnCount; c++) {
                String row = tileMap[r];
                char tileMapChar = row.charAt(c);

                int x = c*tileSize;
                int y = r*tileSize;

                if (tileMapChar == 'B') {
                    Block buisson2Block = new Block(buisson2, x, y, tileSize, tileSize);
                    buisson2s.add(buisson2Block);
                }
                else if (tileMapChar == 'E') { 
                    Block eauBlock = new Block(eau, x, y, tileSize, tileSize);
                    eaus.add(eauBlock);
                }
                else if (tileMapChar == 'N') { 
                    Block nenuBlock = new Block(nenuphare, x, y, tileSize, tileSize);
                    nenuphares.add(nenuBlock);
                }
                else if (tileMapChar == 'P') { 
                    Block pelousBlock = new Block(pelouse, x, y, tileSize, tileSize);
                    pelouses.add(pelousBlock);
                }
                else if (tileMapChar == 'R') { 
                    Block routeBlock = new Block(route, x, y, tileSize, tileSize);
                    routes.add(routeBlock);
                }
            }
        }
        /*for(int i=0;i<rowCount;i++)
        {
            for(int j=0;j<columnCount;i++)
            {
                if(terrain.getTerrain()[i][j]==1)
                {

                }
            }
        }*/
    }

    /*public void setFroggy(Block b)
    {
        this.Froggy=b;
    }*/

    public char getDirection()
    {
        return this.direction;
    }

    public void setDirection(char c)
    {   
        this.direction=c;
    }

    public HashSet<Tronc> getTroncs()
    {
        return troncs;
    }


    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        for (Block buisson2 : buisson2s) {
            g.drawImage(buisson2.image, buisson2.x, buisson2.y, buisson2.width, buisson2.height, null);
        }
        for (Block eau : eaus) {
            g.drawImage(eau.image, eau.x, eau.y, eau.width, eau.height, null);
        }

        for (Block nenu : nenuphares) {
            g.drawImage(nenu.image, nenu.x, nenu.y, nenu.width, nenu.height, null);
        }

        for (Block pel : pelouses) {
            g.drawImage(pel.image, pel.x, pel.y, pel.width, pel.height, null);
        }

        for (Block route : routes) {
            g.drawImage(route.image, route.x, route.y, route.width, route.height, null);
        }

        if(voitures.size()>0){
            for (Voiture voiture : voitures) {
                g.drawImage(voiture.getBlock().image, voiture.getBlock().x*tileSize, voiture.getBlock().y*tileSize, voiture.getBlock().width, voiture.getBlock().height,null);
            }
        }

        if(troncs.size()>0){
            for (Tronc tronc : troncs) {
                g.drawImage(tronc.getBlock().image, tronc.getBlock().x*tileSize, tronc.getBlock().y*tileSize, tronc.getBlock().width, tronc.getBlock().height,null);
            }
        }

        if(grenouilles.size()>0){
            for (Grenouille grenouille : grenouilles) {
                g.drawImage(grenouille.getBlock().image, grenouille.getBlock().x*tileSize, grenouille.getBlock().y*tileSize, grenouille.getBlock().width, grenouille.getBlock().height, null);
            }
        }

        if(Froggy!=null){
            g.drawImage(Froggy.getBlock().image, Froggy.getBlock().x*tileSize, Froggy.getBlock().y*tileSize, Froggy.getBlock().width, Froggy.getBlock().height, null);
        }
        //g.drawImage(voiture2.getBlock().image, voiture2.getBlock().x*tileSize, voiture2.getBlock().y*tileSize, voiture2.getBlock().width, voiture2.getBlock().height,null);
        //score
        
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            this.direction='H';
        }
        else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            this.direction='B';
        }
        else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            this.direction='G';
        }
        else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            this.direction='D';
        }
    }

    
}

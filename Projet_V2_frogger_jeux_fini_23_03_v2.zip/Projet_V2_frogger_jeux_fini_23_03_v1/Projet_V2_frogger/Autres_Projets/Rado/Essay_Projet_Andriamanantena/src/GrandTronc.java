import javax.swing.ImageIcon;

public class GrandTronc extends Tronc{
    public GrandTronc(int posY,Map m, int c,int v){
        super(posY, m, c, v);
        //this.cote=c;
        if(cote==1){
            this.x=-7;
            this.image=new ImageIcon(getClass().getResource("./image/grandtronc.png")).getImage();
            this.limite=19;
            
        }
        else{
            this.x=19;
            this.image=new ImageIcon(getClass().getResource("./image/grandtronc2.png")).getImage();
            this.limite=-7;
        }
        //this.y=posY;
        this.taille=7;
        this.block= new Block(image,x,y,tileSize*taille,tileSize);
        //this.terrain=m;
        this.tabX=new int[taille];
        for(int i=0;i<taille;i++)
        {
            tabX[i]=x+i;
        }
    }
}

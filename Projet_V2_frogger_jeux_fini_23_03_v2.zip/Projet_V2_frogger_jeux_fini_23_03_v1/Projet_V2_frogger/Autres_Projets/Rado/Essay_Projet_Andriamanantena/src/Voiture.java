import java.awt.Image;

abstract class Voiture implements Runnable{

    protected String type;
    protected String nom;
    protected int x;
    protected int y;
    protected int taille;
    protected Image image;
    protected int tileSize = 32;
    protected Block block;
    //private JMap Jterrain;
    protected Map terrain;
    protected int limite;
    protected int cote;
    protected int vitesse;
    protected boolean encours;
    protected int intX;

    public Voiture(int posY,Map m, int c,int v){
        this.cote=c;
        /*if(cote==1){
            this.x=-2;
            this.image=new ImageIcon(getClass().getResource("./image/voiture.png")).getImage();
            this.limite=19;
            
        }
        else{
            this.x=19;
            this.image=new ImageIcon(getClass().getResource("./image/voiture2.png")).getImage();
            this.limite=-2;
        }*/
        this.y=posY;
        //this.block= new Block(image,x,y,tileSize*2,tileSize);
        //this.taille=2;
        this.terrain=m;
        this.vitesse=v;
        this.encours=true;
    }

    /*public void setX(int i){
        this.x=i;
    }

    public void setImage(Image i){
        this.image=i;
    }

    public void setLimite(int i){
        this.limite=i;
    }

    public void setTaille(int i){
        this.taille=i;
    }*/

    public void rouler()
    {
        if(cote==1){
            this.x++;
        }
        else{
            this.x--;
        }
    }

    public Block getBlock()
    {
        return this.block;
    }

    public int getX()
    {
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public boolean getEncours()
    {
        return encours;
    }

    @Override
    public void run() {
            while(true)
            {
                //terrain.debugMap();
                this.rouler();
                if(cote==1){
                    terrain.rouleVoitureGD(x,y,taille);
                    if(x>limite)
                        break;
                }
                else{
                    terrain.rouleVoitureDG(x, y, taille);
                    if(x<limite)
                        break;
                }
                block.set(x, y);
                try{
                    Thread.sleep(vitesse);
                }catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
            System.err.println("fini");
            this.encours=false;

    }
}

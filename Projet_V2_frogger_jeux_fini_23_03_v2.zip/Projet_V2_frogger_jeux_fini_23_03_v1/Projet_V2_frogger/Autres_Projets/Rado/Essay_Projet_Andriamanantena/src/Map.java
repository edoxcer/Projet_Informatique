public class Map {
    private int rowCount;
    private int columnCount;
    //private int tileSize;
    //private String[] tileMap;
    private int[][] terrain;
    private int posX;
    private int posY;

    //0-vide
    //1-grenouille normal
    //2-voiture
    //3-zone interdite
    //4-victoire

    public Map()
    {
        rowCount = 21;//y//i
        columnCount = 19;//x//j
        //int tileSize = 32;
        /*String[] tileMap = {
        "BBBBBBBBBBBBBBBBBBB",
        "BBBBBBBBBBBBBBBBBBB",
        "BBBNBBBNBBBNBBBNBBB",
        "EEEEEEEEEEEEEEEEEEE",
        "EEEEEEEEEEEEEEEEEEE",
        "EEEEEEEEEEEEEEEEEEE",
        "EEEEEEEEEEEEEEEEEEE",
        "EEEEEEEEEEEEEEEEEEE",
        "EEEEEEEEEEEEEEEEEEE",
        "EEEEEEEEEEEEEEEEEEE",
        "PPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPP",
        "RRRRRRRRRRRRRRRRRRR",
        "RRRRRRRRRRRRRRRRRRR",
        "RRRRRRRRRRRRRRRRRRR",
        "RRRRRRRRRRRRRRRRRRR",
        "RRRRRRRRRRRRRRRRRRR",
        "RRRRRRRRRRRRRRRRRRR",
        "PPPPPPPPPPPPPPPPPPP",
        "PPPPPPPPPPPPPPPPPPP" 
        };*/
        terrain=new int[rowCount][columnCount];

        initMap();
    }

    public int[][] getTerrain()
    {
        return this.terrain;
    }

    public void initMap(){
        for(int i=0;i<=2;i++)
        {
            for(int j=0;j<columnCount;j++)
            {
                terrain[i][j]=3;
            }
        }
        for(int i=3;i<=9;i++)
        {
            for(int j=0;j<columnCount;j++)
            {
                terrain[i][j]=3;
            }
        }
        for(int i=10;i<rowCount;i++)
        {
            for(int j=0;j<columnCount;j++)
            {
                terrain[i][j]=0;
            }
        }
        terrain[2][3]=4;
        terrain[2][7]=4;
        terrain[2][11]=4;
        terrain[2][15]=4;
    }

    public void debugMap()
    {
        for(int i=0;i<11;i++)
        {
            for(int j=0;j<columnCount;j++)
            {
                System.out.print(terrain[i][j]);
            }
            System.out.println();
        }
    }

    public void ajoutGrenouille(int x,int y)
    {
        if(terrain[y][x]==0)
        {
            terrain[y][x]=1;
        }
    }

    public boolean setXY_sur_eau(int x,int y,int predX){
        if(x>=0 && x<columnCount && y>=0 && y<rowCount)
        {
            terrain[y][x]=1;
            terrain[y][predX]=1;
            //debugMap();
            return true;
        }
        return false;
    }

    public int move(int x,int y,int veloX,int veloY)
    {   
        if(x>=0 && x<columnCount && y>=0 && y<rowCount)
        {
            if(terrain[y][x]==3 || terrain[y][x]==1)
            {
                return 2;
            }
            else 
            {
                if(terrain[y][x]==0){
                    terrain[y][x]=1;
                    terrain[y-veloY][x-veloX]=0;
                    //debugMap();
                    return 0;
                }
                else if(terrain[y][x]==4){
                    terrain[y-veloY][x-veloX]=0;
                    return 3;
                }
                else{
                    //terrain[y][x]=1;
                    terrain[y-veloY][x-veloX]=0;
                    return 1;
                }
            }
        }
        return 2;
    }

    public boolean collision(int x,int y)
    {
        if(x>=0 && x<columnCount && y>=0 && y<rowCount)
        {
            if(terrain[y][x]!=1)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        return false;
    }

    

    public void rouleVoitureGD(int x,int y,int taille){

        for(int i=taille-1;i>=0;i--)
        { 
            if((x+i>=0 && x+i<columnCount))
            {
                terrain[y][x+i]=2;
                if(x+i!=0){
                    terrain[y][x+i-1]=0;
                }
            }
            if(x+i==columnCount)
            {
                terrain[y][columnCount-1]=0;
            }
        }
        //debugMap();
    }

    public void rouleVoitureDG(int x,int y,int taille){
        for(int i=0;i<taille;i++)
        { 
            if((x+i>=0 && x+i<columnCount))
            {
                terrain[y][x+i]=2;
                if(x+i!=columnCount-1){
                    terrain[y][x+i+1]=0;
                }
            }
            if(x+i==-1)
            {
                terrain[y][0]=0;
            }
        }
        //debugMap();
    }

    public void TroncGD(int x,int y,int taille){
        for(int i=taille-1;i>=0;i--)
        { 
            if((x+i>=0 && x+i<columnCount))
            {
                terrain[y][x+i]=0;
                if(x+i!=0){
                    terrain[y][x+i-1]=3;
                    if(x+i!=1){
                        terrain[y][x+i-2]=3;
                    }
                }
            }
            if(x+i==columnCount)
            {
                terrain[y][columnCount-1]=3;
            }
        }
        //debugMap();
    }

    public void TroncDG(int x,int y,int taille){
        for(int i=0;i<taille;i++)
        { 
            if((x+i>=0 && x+i<columnCount))
            {
                terrain[y][x+i]=0;
                if(x+i!=columnCount-1){
                    terrain[y][x+i+1]=3;
                    if(x+i!=columnCount-2){
                        terrain[y][x+i+2]=3;
                    }
                }
            }
            if(x+i==-1)
            {
                terrain[y][0]=3;
            }
        }
        //debugMap();
    }
}



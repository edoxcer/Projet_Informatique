import javax.swing.ImageIcon;

public class GrandCamion extends Voiture{
    public GrandCamion(int posY, Map m, int c,int v) {
        super(posY, m, c, v);
        if(cote==1){
            this.x=-5;
            this.image=new ImageIcon(getClass().getResource("./image/grandcamion.png")).getImage();
            this.limite=23;
            
        }
        else{
            this.x=19;
            this.image=new ImageIcon(getClass().getResource("./image/grandcamion2.png")).getImage();
            this.limite=-5;
        }
        this.taille=5;
        this.block= new Block(image,x,y,tileSize*taille,tileSize);
        this.intX=x;
    }
}

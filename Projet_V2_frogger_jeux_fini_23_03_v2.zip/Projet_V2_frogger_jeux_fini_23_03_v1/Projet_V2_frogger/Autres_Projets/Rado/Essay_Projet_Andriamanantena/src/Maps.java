import java.util.HashSet;

import javax.swing.JFrame;


class Maps extends JFrame{
    int rowCount = 21;
    int columnCount = 19;
    int tileSize = 32;
    int boardWidth = columnCount * tileSize;
    int boardHeight = rowCount * tileSize;


    public Maps(){
    JFrame frame = new JFrame("Jeu Test");
    frame.setVisible(true);
    frame.setSize(boardWidth, boardHeight);
    frame.setLocationRelativeTo(null);
    frame.setResizable(false);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    Map map=new Map();
    Grenouille grenouille=new Grenouille("bob", "normal", 0, 20,map);
    HashSet<Grenouille> grenouilles=new HashSet<Grenouille>();
    //grenouilles.add(grenouille);
    Thread thd=new Thread(grenouille);
    SimuleObjet essay=new SimuleObjet(map, 1000);
    VoitureBleu voiture=new VoitureBleu(18,map,1,1000);
    VoitureBleu voiture2=new VoitureBleu(17,map,0,1000);
    GrandCamion voiture3=new GrandCamion(16,map,1,1000);
    Tronc tronc=new GrandTronc(9,map,1,1000);
    Tronc tronc2=new GrandTronc(8,map,0,1000);
    Thread thd2=new Thread(voiture);
    Thread thd3=new Thread(voiture2);
    Thread thd4=new Thread(tronc);
    Thread thd5=new Thread(tronc2);
    Thread thd6=new Thread(voiture3);
    HashSet<Thread> threads=new HashSet<Thread>();
    HashSet<Voiture> voitures=new HashSet<Voiture>();
    HashSet<Tronc> troncs=new HashSet<Tronc>();
    voitures.add(voiture);
    voitures.add(voiture2);
    voitures.add(voiture3);
    troncs.add(tronc);
    troncs.add(tronc2);
    threads.add(thd);
    threads.add(thd2);
    threads.add(thd3);
    threads.add(thd4);
    threads.add(thd5);
    threads.add(thd6);
    JMap Jmap = new JMap(grenouilles,threads,map,grenouille,voitures ,troncs);
    frame.add(Jmap);
    Jmap.requestFocus();
    frame.pack();
    frame.setVisible(true);
    }

}



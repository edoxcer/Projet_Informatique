//
// Created by basti on 27/10/2025.
//
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>

#define PORT 5050
#define TAILLE_BUF 128

//affiche message erreur
void panic (const char *msg) {
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[]){

/*gpt

    int sock = 0;                           // Descripteur de la socket (comme un identifiant de fichier)
    struct sockaddr_in serv_addr;           // Structure contenant l'adresse du serveur (IP + port)
    char buffer[1024] = {0};                // Tampon pour recevoir les messages du serveur

    // Création de la socket
    // AF_INET = IPv4, SOCK_STREAM = TCP (connexion fiable orientée flux)
    if((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("Erreur de creation de socket");                         // err si la création échoue
        return 1;
    }

    // Remplissage de la structure d’adresse du serveur
    serv_addr.sin_family = AF_INET;                         // Type d’adresse : IPv4
    serv_addr.sin_port = htons(PORT);                       // Port du serveur (conversion en "network byte order")

    // Convertit la chaîne "127.0.0.1" (localhost) en format binaire d’adresse IP et la met dans serv_addr.sin_addr
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    // Tentative de connexion au serveur via la socket
    if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0){
        perror("connection failed");        // Si la connexion échoue, affiche une erreur
        return 1;
    }

    printf("Connecté au serveur (humain)\n");  // Confirmation de la connexion

    // Boucle principale de communication avec le serveur
    while(1){
        memset(buffer,0,sizeof(buffer));        // Vide le tampon avant chaque réception
        int valread = recv(sock, buffer, sizeof(buffer)-1, 0); // Reçoit un message du serveur
        if(valread <= 0) break;                 // Si le serveur ferme la connexion, on sort
        printf("%s", buffer);                   // Affiche le message reçu (par ex. "MAIN ...")

        // Si le message commence par "MAIN", cela signifie que le serveur envoie la main du joueur
        if(strncmp(buffer,"MAIN",4)==0){
            printf("Entrez une carte à jouer : ");  // Demande à l'utilisateur quelle carte jouer
            int card;
            scanf("%d",&card);                      // Lecture de la carte au clavier
            char msg[64];
            snprintf(msg,sizeof(msg),"PLAY %d\n",card); // Prépare le message à envoyer au serveur
            send(sock,msg,strlen(msg),0);              // Envoie la carte jouée au serveur
        }
    }

    // Fermeture propre de la socket quand la boucle se termine
    close(sock);
   */
    //le prof
    int descClient;
    int lgMsg = TAILLE_BUF;
    struct sockaddr_in addrServ;
    struct sockaddr_in addrClient;
    char *buf = (char*) malloc (TAILLE_BUF);

    /*bug marche pas
    struct hostent *hote = gethostbyname(argv[1]);
    if (hote == NULL)
      panic("Serveur not found");
    */

    // correction Test si l'argument est une adresse IP (ex: "127.0.0.1")
    if (inet_addr(argv[1]) != INADDR_NONE) {
        addrServ.sin_addr.s_addr = inet_addr(argv[1]);
    } else {
        struct hostent *hote = gethostbyname(argv[1]);
        if (hote == NULL)
            panic("Serveur not found");
        memcpy(&addrServ.sin_addr, hote->h_addr_list[0], hote->h_length);
    }


    //obtention d'un desc socket valide
    descClient = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);

    //nommage du socket client tel qu'il le serait par defaut
    addrClient.sin_family = AF_INET;
    addrClient.sin_addr.s_addr = INADDR_ANY; //recupere l'adresse de la machine locale
    addrClient.sin_port =  htons(0); //affecte le premier numero de port libre
    bind (descClient,(struct sockaddr *) &addrClient,(sizeof(struct sockaddr_in)));

    //nom du socket du serveur serveur
    addrServ.sin_family = AF_INET;

    //addrServ.sin_addr.s_addr = inet_addr (inet_ntoa (*(struct in_addr *)(hote->h_addr_list[0]))); //bug

    addrServ.sin_port = htons (atoi (argv[2]));

    if (connect(descClient,(struct sockaddr *) &addrServ,(sizeof(struct sockaddr_in))) == -1)
        panic ("Connexion ratée");

    write(descClient,argv[3],strlen(argv[3]));
    read(descClient,buf,TAILLE_BUF);
    printf("Accusé de reception: %s\n",buf);

    //quitter proprement
    close (descClient);
    exit (0);

}


set -e

cd /home/basti/_cygwing/SystemEtReseau/projet/cmake-build-debug
/cygdrive/c/Users/basti/AppData/Local/JetBrains/CLion2025.2/cygwin_cmake/bin/cmake.exe -E echo No\ interactive\ CMake\ dialog\ available.

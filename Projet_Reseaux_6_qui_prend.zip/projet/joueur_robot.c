#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

#define PORT 5050

int main(){
    srand(time(NULL));
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[2048] = {0};

    if((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("socket");
        return 1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0){
        perror("connect");
        return 1;
    }

    printf("Bot connecté au serveur.\n");

    while(1){
        memset(buffer,0,sizeof(buffer));
        int n = recv(sock, buffer, sizeof(buffer)-1, 0);
        if(n <= 0) break;

        if(strncmp(buffer,"MAIN",4)==0){
            int hand[10], cnt=0;
            char *tok = strtok(buffer+4," \n");
            while(tok && cnt<10){ hand[cnt++]=atoi(tok); tok=strtok(NULL," \n"); }
            int choice = hand[rand()%cnt];
            char msg[64];
            snprintf(msg,sizeof(msg),"PLAY %d\n",choice);
            send(sock,msg,strlen(msg),0);
            printf("Bot joue %d\n",choice);
        }
    }

    close(sock);
    return 0;
}

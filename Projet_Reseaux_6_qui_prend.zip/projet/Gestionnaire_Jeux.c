#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <signal.h>

#define MAX_Joueur 2
#define Nb_Carte_Totale 104
#define Carte_par_Joueur 10
#define TAILLE_BUF 128
#define NB_manche  10
#define PORT 5050
#define SCORE_LIMITE 66
typedef enum {
    ETAT_PIOCHE,    // pas encore utilisée
    ETAT_MAIN,      // distribuée à un joueur
    ETAT_PLATEAU,   // sur le plateau
    ETAT_JOUEE      // jouée pendant un tour (ou défaussée)
} EtatCarte;


typedef struct {
    int valeur;   // de 1 à 104
    int boeufs;   // nombre de têtes
    EtatCarte etat;
    int Joueur_id;
} Carte;

typedef struct{
    Carte cartes[Carte_par_Joueur];
    int id;
    int score;
    int nb_cartes;

}
Joueur;



void panic (const char *msg)
{
    perror(msg); exit(1);
}
void fin (int sig) {
    int descServ;
    if (close (descServ) != -1)
        printf("Descripteur bien fermé\n");
    exit(0);
}


// attributs global
Carte plateau[4][6]; // 4 rangées, max 6 cartes
Carte cartes[Nb_Carte_Totale];
int nb_cartes_par_rangee[4] = {0};
int nb_cartes_par_col[6] = {0};
Joueur Lst_joueur[MAX_Joueur];


void error(char *msg)
{
    perror(msg);
    exit(1);
}

// Calcule des bœufs selon les règles
int calculer_boeufs(Carte *c) {
    int v = c->valeur;

    if (v == 55)
        c->boeufs = 7;
    else if (v % 11 == 0)
        c->boeufs = 5;
    else if (v % 10 == 0)
        c->boeufs = 3;
    else if (v % 5 == 0)
        c->boeufs = 2;
    else
        c->boeufs = 1;

    //printf("Attribution : carte %d → %d boeufs\n", c->valeur, c->boeufs);
    return c->boeufs;
    }



void Initialisation_Plateaux_vide()
{
    for (int i = 0; i < 4; i++)
    {
        nb_cartes_par_rangee[i] = 0;
        for (int j = 0; j < 6; j++)
        {
            plateau[i][j].valeur = 0;
            plateau[i][j].boeufs = 0;
        }
    }
}
void Afficher_Plateaux()
{
    for (int i = 0; i < 4; ++i)
    {
        for (int j = 0;j < 6; j++)
        {
            printf("%d (%d B) ",plateau[i][j].valeur,plateau[i][j].boeufs);
        }
        printf(" \n");
    }
}
void Afficher_score()
{
    for (int i = 0; i < MAX_Joueur; i++)
    {
        printf("le score du joueur %d est de : %d \n",Lst_joueur[i].id,Lst_joueur[i].score);
    }
}


// Tire une carte non encore utilisée
int tirer_carte_non_utilisee() {
    int indice;
    do {
        indice = rand() % Nb_Carte_Totale;
    } while (cartes[indice].etat != ETAT_PIOCHE);
    cartes[indice].etat = ETAT_MAIN;
    return indice;
}
int tirer_carte_alea(EtatCarte nouvel_etat) {
    int indice;
    do {
        indice = rand() % Nb_Carte_Totale;
    } while (cartes[indice].etat != ETAT_PIOCHE);
    cartes[indice].etat = nouvel_etat;
    return indice;
}



void Initalisation_Joueur() {
    for (int i = 0; i < MAX_Joueur; i++) {
        Lst_joueur[i].id = i + 1;
        Lst_joueur[i].score = 0;
        Lst_joueur[i].nb_cartes = Carte_par_Joueur;
        for (int j = 0; j < Carte_par_Joueur; j++) {
            int idx = tirer_carte_alea(ETAT_MAIN);
            Lst_joueur[i].cartes[j] = cartes[idx];
            Lst_joueur[i].cartes[j].etat = ETAT_MAIN;
        }
    }
}
void Initialisation_Carte() {
    for (int i = 0; i < Nb_Carte_Totale; i++) {
        cartes[i].valeur = i + 1;
        calculer_boeufs(&cartes[i]);
        cartes[i].etat = ETAT_PIOCHE;
    }
}


int Score_Ligne(int ligne){
    int score = 0;
    for (int i = 0; i < nb_cartes_par_rangee[ligne]; i++) // on peut pas mettre 6 car nos ligne peuvent etre vide
    {
        score += plateau[ligne][i].boeufs;
    }
    return score;
}

void Afficher_carte()
{
    for (int i = 0; i < MAX_Joueur; i++)
    {
        int cpt =0;
        for (int k = 0; k < Carte_par_Joueur; k++)
        {
            if (Lst_joueur[i].cartes[k].valeur != 0)
            {
                cpt ++;
            }
        }
        printf("les carte du joueur %d\n ",Lst_joueur[i].id);

        for (int j = 0; j < cpt; j++)
        {
            if (Lst_joueur[i].cartes[j].etat == ETAT_MAIN)
            {
                printf("cartes : %d \n",Lst_joueur[i].cartes[j].valeur);
            }

        }
    }
}

void trier_carte(Carte cartes[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int min = i;
        for (int j = i + 1; j < n; j++) {
            if (cartes[j].valeur < cartes[min].valeur) {
                min = j;
            }
        }
        if (min != i) {
            Carte tmp = cartes[i];
            cartes[i] = cartes[min];
            cartes[min] = tmp;
        }
    }
}



void Initialisation_Plateaux() {
    for (int i = 0; i < 4; i++) {
        int idx = tirer_carte_alea(ETAT_PLATEAU); // choisit une carte libre et la marque ETAT_PLATEAU
        plateau[i][0] = cartes[idx];
        nb_cartes_par_rangee[i] = 1;
    }
}

void afficher_etat_de_la_carte(Carte c) {
    printf("Carte %3d : etat = %d\n", c.valeur, c.etat);
}
void afficher_etat_cartes() {
    for (int i = 0; i < Nb_Carte_Totale; i++) {
        printf("Carte %3d : etat = %d\n", cartes[i].valeur, cartes[i].etat);
    }
}

int mise_a_jour_carte_joueur(Carte main_joueur[], int nb_cartes) {
    int nouvelle_taille = 0;

    for (int i = 0; i < nb_cartes; i++) {
        if (main_joueur[i].etat == ETAT_MAIN) {
            // carte encore dans la main
            main_joueur[nouvelle_taille++] = main_joueur[i];
        }
    }

    // vider le reste proprement
    for (int i = nouvelle_taille; i < Carte_par_Joueur; i++) {
        main_joueur[i].valeur = -1;
        main_joueur[i].boeufs = 0;
        main_joueur[i].etat = ETAT_JOUEE;
    }

    return nouvelle_taille;
}


/*void placer_carte(Joueur *joueur, Carte c)
{
    int ligne_cible = -1;
    int meilleure_valeur = -1;

        for (int l = 0; l < 4; l++) {
            int nb = nb_cartes_par_rangee[l];
            if (nb > 0 && plateau[l][nb - 1].valeur < c.valeur && plateau[l][nb - 1].valeur > meilleure_valeur) {
                meilleure_valeur = plateau[l][nb - 1].valeur;
                ligne_cible = l;
            }
        }

    // 2️⃣ Si aucune ligne ne peut accueillir la carte → le joueur doit ramasser une ligne
    if (ligne_cible == -1) {
        printf("Joueur %d, entrez la ligne que vous voulez ramasser (1–4) : ", joueur->id);
        scanf("%d", &ligne_cible);
        ligne_cible--; // on convertit en index 0–3

        printf("  Joueur %d ramasse la ligne %d !\n", joueur->id, ligne_cible + 1);
        joueur->score += Score_Ligne(ligne_cible);
        nb_cartes_par_rangee[ligne_cible] = 0; // on vide la ligne
    }

    // 3️⃣ Si la ligne atteint 6 cartes → le joueur ramasse aussi
    if (nb_cartes_par_rangee[ligne_cible] == 5) {
        printf("  Ligne %d a atteint 6 cartes ! Joueur %d ramasse la ligne.\n", ligne_cible + 1, joueur->id);
        joueur->score += Score_Ligne(ligne_cible);
        nb_cartes_par_rangee[ligne_cible] = 0;
    }
    if (nb_cartes_par_rangee[ligne_cible] >= 6) {
        printf("Erreur : la ligne %d dépasse 6 cartes !\n", ligne_cible + 1);
        return;
    }

    // 4️⃣ On place la carte sur la ligne
    plateau[ligne_cible][nb_cartes_par_rangee[ligne_cible]] = c;
    nb_cartes_par_rangee[ligne_cible]++;

    printf("  Carte %d placée sur la ligne %d (position %d)\n",
           c.valeur, ligne_cible + 1, nb_cartes_par_rangee[ligne_cible]);
    printf("Score actuel du joueur %d : %d points\n", joueur->id, joueur->score);
}*/
/*void placer_carte(Joueur *joueur, Carte c) {
    int ligne_cible = -1;
    int meilleure_valeur = -1;
    int idx = tirer_carte(ETAT_MAIN);     // pour un joueur
    // DEBUG : afficher dernières cartes de chaque rangée
    for (int l = 0; l < 4; l++) {
        if (nb_cartes_par_rangee[l] > 0) {
            int last_val = plateau[l][nb_cartes_par_rangee[l] - 1].valeur;
            printf("[DEBUG] Rangee %d, derniere carte = %d\n", l+1, last_val);
        } else {
            printf("[DEBUG] Rangee %d est vide\n", l+1);
        }
        // 4️⃣ Mise à jour de l’état de la carte jouée
        for (int i = 0; i < Nb_Carte_Totale; i++) {
            if (cartes[i].valeur == c.valeur) {
                cartes[i].etat = ETAT_PLATEAU;
                break;
            }
        }

    }

    // Recherche de la ligne dont la dernière carte est la plus grande < c.valeur
    for (int l = 0; l < 4; l++) {
        int nb = nb_cartes_par_rangee[l];
        if (nb > 0) {
            int last = plateau[l][nb - 1].valeur;
            if (last < c.valeur && last > meilleure_valeur) {
                meilleure_valeur = last;
                ligne_cible = l;
            }
        }
    }

    // Si aucune ligne n'a last < c.valeur -> le joueur ramasse une ligne (demander choix)
    if (ligne_cible == -1) {
        int choix = 0;
        printf("Joueur %d, aucune ligne possible. Entrez la ligne à ramasser (1-4) : ", joueur->id);
        scanf("%d", &choix);
        choix--; // transformer en 0..3
        if (choix < 0 || choix >= 4) choix = 0; // sécurité
        printf("  Joueur %d ramasse la ligne %d\n", joueur->id, choix+1);
        joueur->score += Score_Ligne(choix);

        // vider la ligne choisie
        nb_cartes_par_rangee[choix] = 0;
        // placer ensuite la carte comme première carte de cette ligne
        plateau[choix][0] = c;
        nb_cartes_par_rangee[choix] = 1;
        printf("  Carte %d placée sur la ligne %d (position 1)\n", c.valeur, choix+1);
        return;
    }

    // Si on a une ligne cible, vérifier si elle va atteindre 6 cartes (i.e. nb == 5 avant ajout)
    if (nb_cartes_par_rangee[ligne_cible] == 6 - 1) { // 5 si MAX_COL==6
        // Le joueur ramasse la ligne complète
        printf("  Ligne %d atteint 6 cartes : Joueur %d ramasse la ligne\n", ligne_cible+1, joueur->id);
        joueur->score += Score_Ligne(ligne_cible);
        // vider ligne puis placer la carte comme première
        nb_cartes_par_rangee[ligne_cible] = 0;
        plateau[ligne_cible][0] = c;
        nb_cartes_par_rangee[ligne_cible] = 1;
        printf("  Carte %d placée sur la ligne %d (position 1)\n", c.valeur, ligne_cible+1);
        return;
    }

    // Cas normal : on ajoute la carte à la fin de la ligne_cible
    int pos = nb_cartes_par_rangee[ligne_cible];
    plateau[ligne_cible][pos] = c;
    nb_cartes_par_rangee[ligne_cible] = pos + 1;
    printf("  Carte %d placée sur la ligne %d (position %d)\n", c.valeur, ligne_cible + 1, pos + 1);
}*/

/* placer_carte : place la carte c pour joueur donné (logique simplifiée) */
void placer_carte_auto(Joueur *joueur, Carte c) {
    int ligne_cible = -1;
    int meilleure_valeur = -1;

    // recherche de la ligne dont la dernière carte est la plus grande < c.valeur
    for (int l = 0; l < 4; l++) {
        int nb = nb_cartes_par_rangee[l];
        if (nb > 0) {
            int last = plateau[l][nb - 1].valeur;
            if (last < c.valeur && last > meilleure_valeur) {
                meilleure_valeur = last;
                ligne_cible = l;
            }
        }
    }

    if (ligne_cible == -1) {
        // cas où aucune ligne ne convient : le joueur ramasse la plus petite ligne (stratégie automatique)
        int minHeads = 100000;
        int idx = 0;
        for (int l = 0; l < 4; l++) {
            int s = 0;
            for (int k = 0; k < nb_cartes_par_rangee[l]; k++)
            {
                s += plateau[l][k].boeufs;
            }
            if (s < minHeads)
            {
                minHeads = s;
                idx = l;
            }
        }
        printf("Joueur %d ramasse la ligne %d (automatique) +%d boeufs\n", joueur->id, idx+1, minHeads);
        joueur->score += minHeads;
        // vider ligne idx
        nb_cartes_par_rangee[idx] = 0;
        // placer la carte comme première de la ligne
        plateau[idx][0] = c;
        nb_cartes_par_rangee[idx] = 1;
        return;
    }

    // si la ligne cible a 5 cartes (avant l'ajout) -> le joueur prend la ligne
    if (nb_cartes_par_rangee[ligne_cible] == 5) {
        int taken = Score_Ligne(ligne_cible);
        printf("Ligne %d pleine -> joueur %d ramasse %d boeufs\n", ligne_cible+1, joueur->id, taken);
        joueur->score += taken;
        // vider et mettre c en premiere position
        nb_cartes_par_rangee[ligne_cible] = 0;
        plateau[ligne_cible][0] = c;
        nb_cartes_par_rangee[ligne_cible] = 1;
        return;
    }

    // cas normal : ajouter c en fin de ligne
    int pos = nb_cartes_par_rangee[ligne_cible];
    plateau[ligne_cible][pos] = c;
    nb_cartes_par_rangee[ligne_cible] = pos + 1;
    printf("Carte %d placée sur la ligne %d (position %d)\n", c.valeur, ligne_cible+1, pos+1);
}
void placer_carte(Joueur *joueur, Carte c)
{
    int ligne_cible = -1;
    int meilleure_valeur = -1;

    // recherche de la ligne dont la dernière carte est la plus grande < c.valeur
    for (int l = 0; l < 4; l++) {
        int nb = nb_cartes_par_rangee[l];
        int cpt =0;
        if (nb > 0) {
            int last = plateau[l][nb - 1].valeur;
            if (last < c.valeur && last > meilleure_valeur) {
                meilleure_valeur = last;
                ligne_cible = l;
            }
        }
        // parcours du plateau pour verif si une ligne est complète ou pas
    }
    if (ligne_cible == -1) {
        printf("\n=== Aucune ligne ne peut accueillir la carte %d ===\n", c.valeur);
        printf("Joueur %d, vous devez choisir une ligne à ramasser :\n", joueur->id);

        // Affichage des lignes et de leur contenu
        Afficher_Plateaux();

        int choix = -1;
        do {
            printf("Entrez le numéro de la ligne à ramasser (0-3) : ");
            scanf("%d", &choix);
        } while (choix < 0 || choix > 3);

        int ligne = choix;

        // calcul des boeufs ramassés
        int total_boeufs = 0;
        for (int k = 0; k < nb_cartes_par_rangee[ligne]; k++) {
            total_boeufs += plateau[ligne][k].boeufs;
        }

        joueur->score += total_boeufs;
        printf("Joueur %d ramasse la ligne %d (+%d boeufs)\n", joueur->id, ligne + 1, total_boeufs);

        // vider la ligne choisie et poser la carte
        nb_cartes_par_rangee[ligne] = 0;
        plateau[ligne][0] = c;
        nb_cartes_par_rangee[ligne] = 1;

        return;
    }
    // cas ou la ligne est complète
    // cas où la ligne cible a déjà 5 cartes -> ligne complète
    if (ligne_cible != -1 && nb_cartes_par_rangee[ligne_cible] == 5) {
        printf("\n=== Ligne %d complète ! Joueur %d ramasse toutes les cartes ===\n", ligne_cible, joueur->id);

        int total_boeufs = 0;
        // calcul du score total
        for (int z = 0; z < nb_cartes_par_rangee[ligne_cible]; z++) {
            total_boeufs += plateau[ligne_cible][z].boeufs;
        }

        joueur->score += total_boeufs;
        printf("Joueur %d gagne %d boeufs\n", joueur->id, total_boeufs);

        // vider la ligne et placer la nouvelle carte comme première
        nb_cartes_par_rangee[ligne_cible] = 0;
        plateau[ligne_cible][0] = c;
        nb_cartes_par_rangee[ligne_cible] = 1;

        return;
    }

    // cas normal : ajouter c en fin de ligne
    int pos = nb_cartes_par_rangee[ligne_cible];
    plateau[ligne_cible][pos] = c;
    nb_cartes_par_rangee[ligne_cible] = pos + 1;
    printf("Carte %d placée sur la ligne %d (position %d)\n", c.valeur, ligne_cible+1, pos+1);
}

/*void Manche_Jeux()
    {
        Initialisation_Carte();
        printf("initialisation des cartes terminée !");
        printf("\n=== Début de la manche ===\n");
        // On suppose 10 tours max
        Initialisation_Plateaux();
        Initalisation_Joueur();
        Afficher_Plateaux();
        for (int tour = 0; tour < NB_manche; tour++)
        {
            printf("\n--- Tour %d ---\n", tour + 1);

            //Chaque joueur choisit une carte
            Carte cartes_jouees[MAX_Joueur];
            for (int i = 0; i < MAX_Joueur; i++) {
                int indice_carte = 0;
                printf("Joueur %d, entrez l’indice de la carte que vous voulez jouer (0–9) : ", Lst_joueur[i].id);
                scanf("%d", &indice_carte);
                // verification de l'indice à faire ultérieurement
                cartes_jouees[i] = Lst_joueur[i].cartes[indice_carte];
                printf("Joueur %d joue la carte %d (%d boeufs)\n",
                       Lst_joueur[i].id,
                       cartes_jouees[i].valeur,
                       cartes_jouees[i].boeufs);
            }

            // on trie les carte dans l'ordre croissant
            trier_carte(cartes_jouees,MAX_Joueur);

            // placement des cartes :
            for (int i = 0; i < MAX_Joueur; i++) {
                placer_carte(&Lst_joueur[i], cartes_jouees[i]);
            }


            // affichage score
            Afficher_Plateaux();
            Afficher_carte();

        }
    }*/
void Manche_Jeux() {
    Initialisation_Carte();
    printf("initialisation des cartes terminée !\n");
    Initialisation_Plateaux_vide();
    Initialisation_Plateaux();
    Initalisation_Joueur();
    Afficher_Plateaux();
    Afficher_carte();
    char reponse;
    printf("le nb de carte est %d",Lst_joueur[0].nb_cartes);
    // mettre un while pour les manche
    for (int tour = 0; tour < 2; tour++) {
        printf("\n--- Tour %d ---\n", tour + 1);
        printf("\n");
        Afficher_Plateaux();
        Carte cartes_jouees[MAX_Joueur];
        for (int i = 0; i < MAX_Joueur; i++) {
            int indice_carte = -1;
            printf("Joueur %d, entrez l'indice de la carte à jouer (0-%d) : ", Lst_joueur[i].id, Lst_joueur[i].nb_cartes-1);
            if (scanf("%d", &indice_carte) != 1) {
                printf("Lecture invalide, sortie.\n");
                return;
            }

            if (indice_carte < 0 || indice_carte >= Lst_joueur[0].nb_cartes || indice_carte >= Lst_joueur[1].nb_cartes) { // changer les bornes pour les cartes dispos en fonction du joueurs 2 comme ça pas de problème avec les borne du j1 ?
                printf("Indice hors borne, on prend 0 par défaut.\n");
                indice_carte = 0;

                // exit ?
            }
            cartes_jouees[i] = Lst_joueur[i].cartes[indice_carte];
            cartes_jouees[i].Joueur_id = Lst_joueur[i].id;
            // marquer la carte comme jouée dans la main
            Lst_joueur[i].cartes[indice_carte].etat = ETAT_JOUEE;
            printf("Joueur %d joue la carte %d (%d boeufs)\n", Lst_joueur[i].id, cartes_jouees[i].valeur, cartes_jouees[i].boeufs);


        }

        // tri des cartes jouées
        trier_carte(cartes_jouees, MAX_Joueur);

        // placement dans l'ordre
        for (int i = 0; i < MAX_Joueur; i++) {
            // retrouver quel joueur a joué cette carte
            for (int j = 0; j < MAX_Joueur; j++) {
                if (Lst_joueur[j].id == cartes_jouees[i].Joueur_id) {
                    placer_carte(&Lst_joueur[j], cartes_jouees[i]);
                    break;
                }
            }
        }

        // on met a jour le nombre de carte disponible pour les joueurs
        for (int i = 0; i < MAX_Joueur; i++) {
            Lst_joueur[i].nb_cartes = mise_a_jour_carte_joueur(Lst_joueur[i].cartes, Lst_joueur[i].nb_cartes);
        }

        Afficher_score();
        Afficher_Plateaux();
        Afficher_carte();
    }

    printf("\n--- Fin de la manche ---\n");
    for (int i = 0; i < MAX_Joueur; i++) {
        printf("Joueur %d score = %d\n", Lst_joueur[i].id, Lst_joueur[i].score);
    }
    /*printf("Voulez vous quitter ? (tapez q)");
    if (scanf("%s",reponse)=='q')
        exit(0);*/
}
void Partie()
{
    int fin =0;
    int manche = 1;
    while (!fin && manche <=NB_manche) // ici 10 manche ou alors le score est de 66
    {
        printf("\n===== MANCHES %d =====\n", manche);
        Manche_Jeux();
        // vérifie les scores
        for (int i = 0; i < MAX_Joueur; i++) {
            printf("Joueur %d : %d têtes de boeufs\n", Lst_joueur[i].id, Lst_joueur[i].score);
            if (Lst_joueur[i].score >= SCORE_LIMITE) {
                fin = 1;
            }
        }

        manche++;
    }

    // fin de partie
    printf("\n===== FIN DE LA PARTIE =====\n");
    int meilleur = 999;
    int gagnant = -1;
    for (int i = 0; i < MAX_Joueur; i++) {
        if (Lst_joueur[i].score < meilleur) {
            meilleur = Lst_joueur[i].score;
            gagnant = Lst_joueur[i].id;
        }
    }
    printf("Le gagnant est le Joueur %d avec %d têtes de boeufs !\n", gagnant, meilleur);
}


int descServ;
int main(int argc, char *argv[]) {
    srand(time(NULL));
    // apelle de la fonction manche ou creation de
    //Manche_Jeux();
    Partie();


    //Serveur
    int descClient;
    socklen_t len;
    socklen_t lg_addr_client = sizeof(struct sockaddr_in);
    struct sockaddr_in addrServ;
    struct sockaddr_in addrClient;
    char *buf = malloc(TAILLE_BUF);
    struct sigaction act;

    descServ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (descServ == -1)
    {
        panic("Erreur création socket");
    }
    // Quitter proprement avec Ctrl+C
    act.sa_handler = fin;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);

    // Autoriser la réutilisation du port immédiatement
    int opt = 1;

    //si port en wait
    if (setsockopt(descServ, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
        perror("setsockopt(SO_REUSEADDR) failed");

    // Nommage du serveur
    addrServ.sin_family = AF_INET;
    addrServ.sin_addr.s_addr = htonl(INADDR_ANY);
    addrServ.sin_port = htons(5050); //localhost

    if (bind(descServ, (struct sockaddr *)&addrServ, sizeof(addrServ)) == -1)
        panic("Erreur de nommage");

    if (getsockname(descServ, (struct sockaddr *)&addrServ, &len) == -1)
        panic("Erreur lors de la recuperation du port");

    printf("Infos sur le serveur:\n");
    printf("\tPort: %d\n", ntohs(addrServ.sin_port));

    listen(descServ, 5);

    for (;;) {
        printf("serveur en attente d'un message\n");
        descClient = accept(descServ, (struct sockaddr *)&addrClient, &lg_addr_client);
        if (descClient == -1)
            panic("Connection ratée");

        read(descClient, buf, TAILLE_BUF);
        sleep(5);
        printf("Message %s recu de %s sur port %d\n",
               buf, inet_ntoa(addrClient.sin_addr), ntohs(addrClient.sin_port));

        write(descClient, "Requete bien traitée", 20);
        close(descClient);
    }

}
